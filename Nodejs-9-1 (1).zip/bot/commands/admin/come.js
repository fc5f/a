const { EmbedBuilder, ButtonStyle, ButtonBuilder, ActionRowBuilder } = require('discord.js');
module.exports = {
  name: 'come',
  description: 'Send a come message to a specific user.',
    aliases: [],
      async execute(client, message, args) {
          try{
             // if (!message.member.roles.cache.has(config.staff)) return;
              const member = message.mentions.members.first() || message.guild.members.cache.get(args[0]);
              if (!member) return message.reply({ content: `**Please mention the user or provide their ID.**` });
              const embed = new EmbedBuilder()
                  .setColor('#000100')
            
.setDescription(`**مرحبا ${member} تم استدعائك من قبل <@${message.author.id}>, اضغط علي الزر بالاسفل**`)
                  .setAuthor({
                      name: message.guild.name,
                      iconURL: message.guild.iconURL()
                  })
                  .setFooter({
                      text: message.author.username,
                      iconURL: message.author.displayAvatarURL()
                  })
                  .setThumbnail(message.guild.iconURL())
                  .setTimestamp();
            const row = new ActionRowBuilder()
                .addComponents(
                    new ButtonBuilder()
                          .setURL(`https://discord.com/channels/${message.guild.id}/${message.channel.id}`)
                          .setLabel('Go to Channel')
                        .setStyle(ButtonStyle.Link)
                )
member.send({ 
embeds: [embed],
components: [row]
});
            const em = new EmbedBuilder()
              .setColor("#000100")
              .setTitle("**استدعاء عضو**")
              .setDescription(`**تم استدعاء العضو بنجاح ${member}**`)
                             .setAuthor({
                      name: message.guild.name,
                      iconURL: message.guild.iconURL()
                  })
                  .setFooter({
                      text: message.author.username,
                      iconURL: message.author.displayAvatarURL()
                  })
                  .setThumbnail(message.guild.iconURL())
                  .setTimestamp();
            message.reply({ embeds: [em] }); 
        } catch (err) {
            console.log(err);
        }
  },
};
