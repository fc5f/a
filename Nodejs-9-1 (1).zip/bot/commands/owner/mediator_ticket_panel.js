const { EmbedBuilder, ApplicationCommandOptionType , Events , ActionRowBuilder , ButtonBuilder ,MessageAttachment, ButtonStyle , Message, TextInputStyle,TextInputBuilder,ModalBuilder, StringSelectMenuBuilder, StringSelectMenuOptionBuilder, PermissionsBitField } = require("discord.js");
module.exports = {
    name: "mediator_panel",
    aliases: [],
    owners: true,
    async execute(client, message, args) {
        try{
        const mediator = new StringSelectMenuBuilder()
        .setCustomId('mediator')
        .setPlaceholder('طلب وسيط')
        .addOptions(
        new StringSelectMenuOptionBuilder()
        .setLabel('وسيط مبتدئ')
        .setValue('mediator_1'),
        new StringSelectMenuOptionBuilder()
        .setLabel('وسيط تجريبي')
        .setValue('mediator_2'),
        new StringSelectMenuOptionBuilder()
        .setLabel('وسيط متوسط')
        .setValue('mediator_3'),
        new StringSelectMenuOptionBuilder()
        .setLabel('وسيط معتمد')
        .setValue('mediator_4'),
        new StringSelectMenuOptionBuilder()
        .setLabel('وسيط موثوق')
        .setValue('mediator_5'),
          new StringSelectMenuOptionBuilder()
          .setLabel('Reset')
          .setValue('reset'),
        );
        const row = new ActionRowBuilder()
        .addComponents(mediator);
        const embed = new EmbedBuilder()
        .setColor("#000100")
        .setDescription(`** قـبـل أن تـطـلـب الـوسـيـط ، يـجـب عـلـيـك قـراء الـقـوانـيـن وسـطاء جـيـد لـتـجـنـب الـبـانـد او بـلاك ليست 
#〢ᨒ・قـوانـيـن・الـوسـطـاء

➥ 丨 الـوسـيـط مـبـتـدئ مـن [ 0 ] الي  [400,000]

➥ 丨 الـوسـيـط الـتـجـريـبـي مـن [400,000] الي  [600,000]

➥ 丨 الـوسـيـط الـمـتـوسـط مـن [600,000] الي  [800,000]

➥ 丨 الـوسـيـط مـعـتـمـد مـن [800,000] الي  [1,600,000]

➥ 丨 الـوسـيـط مـوثـوق  مـن [1,600,000] الي  [3,200,000]\n.  يرجى طلب وسيط على حسب المبلغ المراد والتأكد من رتبة الوسيط و حده الذي يستطيع التوسط عليه. **`)
          .setImage("https://images-ext-1.discordapp.net/external/M6VyN-AXvRsLsR-iP7o_u1TeRX0IW5fE506Bm_lXi5k/https/probot.media/Fm23rP6Ax7.png")
        .setAuthor({
        name: message.guild.name,
        iconURL: message.guild.iconURL()
        })
        .setFooter({
        text: message.guild.name,
        iconURL: message.guild.iconURL()
        })
        .setThumbnail(message.guild.iconURL())
        .setTimestamp();
        message.channel.send({ embeds: [embed], components: [row] });
        } catch (error) {
            console.error(error);
            message.reply('There was an error while executing this command!');
        }
    },
};