const { EmbedBuilder, ButtonStyle, ButtonBuilder, ActionRowBuilder } = require("discord.js");
module.exports = {
        name: "order-panel",
        aliases: [],
         owners: true,
         async execute(client, message, args) {
          try {
const row = new ActionRowBuilder()
.addComponents(
new ButtonBuilder()
.setCustomId('products')
.setLabel('منتجات')
.setStyle(ButtonStyle.Secondary),
new ButtonBuilder()
.setCustomId('design')
.setLabel('تصاميم')
.setStyle(ButtonStyle.Secondary),
new ButtonBuilder()
.setCustomId('program')
.setLabel('برمجيات')
.setStyle(ButtonStyle.Secondary)
);
const embed = new EmbedBuilder()
.setColor('#000100')
.setTitle('يمكنك طلب ما تريد من هنا')
.setDescription(`**
قوانين الطلبات

1-ممنوع طلب منتجات 18+
2-ممنوع طلب اعضاء او بارتنر
3-ممنوع طلب طرق نيترو و كريديت
4-ممنوع طلب اشياء في اماكن خطأ مثل : (تطلب نيترو في روم برمجيات او تصاميم)
5-ممنوع بيع اي شي           
**`)
  .setImage('https://media.discordapp.net/attachments/1213228582126747759/1216124723495178241/image_13.png?ex=65ff3f68&is=65ecca68&hm=fe73046b233b59404672705d7b2f15a8f6f54a4aca204d4ef8f33e2267805e44&')
  .setAuthor({
    name: message.guild.name,
    iconURL: message.guild.iconURL()})
    .setFooter({
    text: message.guild.name,
      iconURL: message.guild.iconURL()
    })

    .setThumbnail(message.guild.iconURL())
  
.setTimestamp();
message.channel.send({ embeds: [embed], components: [row] });
          } catch (error) {
            console.error(error);
            message.reply('There was an error while executing this command!');
          }
        },
};