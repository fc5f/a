const { EmbedBuilder, ApplicationCommandOptionType , Events , ActionRowBuilder , ButtonBuilder ,MessageAttachment, ButtonStyle , Message, TextInputStyle,TextInputBuilder,ModalBuilder, StringSelectMenuBuilder, StringSelectMenuOptionBuilder, PermissionsBitField } = require("discord.js");

module.exports = {
    name: "ticket",
    aliases: [],
    owners: true,
     async execute(client, message, args) {
        try {
    const ticket = new StringSelectMenuBuilder()
    .setCustomId('ticket')
      .setPlaceholder('اختر نوع التذكرة')
      .addOptions(
      new StringSelectMenuOptionBuilder()

    .setLabel('دعم فني')
    .setValue('support'),
      new StringSelectMenuOptionBuilder()
    .setLabel('طلب قاضي')
    .setValue('report'),
        new StringSelectMenuOptionBuilder()
    .setLabel('Reset')
    .setValue('reset'),
  );
    const row = new ActionRowBuilder()
      .addComponents(ticket);
    const embed = new EmbedBuilder()
      .setColor('#000100')
    .setDescription(`**اذا عندك سؤال , عايز تشتري رتبة / اعلان / منشور مميز الخ.. اختار الدعم الفني
اذا حد نصبك اختار طلب مشهر
اذا عندك شكوى على حد من طاقم الادارة اختار شكاوي على طاقم الادارة
        
ملاحظات :
        
تفتح شكوى و تكون على حد مش من طاقم الادارة = مخالفة
استهبال بالتكتات = مخالفة
تفتح تكت ملهاش علاقة بالي عايزه , مثال : تفتح شكوى و عايز تشتري رتبة = مخالفة
        
المخالفة تختلف حسب الغلطة الي سويتها**`)
        .setAuthor({
        name: message.guild.name,
        iconURL: message.guild.iconURL()})
        .setFooter({
        text: message.guild.name,
          iconURL: message.guild.iconURL()
        })

        .setThumbnail(message.guild.iconURL())

    .setTimestamp();
    message.channel.send({ embeds: [embed], components: [row] });
  
       } catch (error) {
            console.error(error);
            message.reply('There was an error while executing this command!');
          }
     },
};