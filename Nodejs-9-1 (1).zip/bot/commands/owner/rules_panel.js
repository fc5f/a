const { EmbedBuilder, ApplicationCommandOptionType , Events , ActionRowBuilder , ButtonBuilder ,MessageAttachment, ButtonStyle , Message, TextInputStyle,TextInputBuilder,ModalBuilder, StringSelectMenuBuilder, StringSelectMenuOptionBuilder, PermissionsBitField } = require("discord.js");

module.exports = {
    name: "rules",
    aliases: [],
     owners: true,
    async execute(client, message, args) {
        try{
                    const embed = new EmbedBuilder()
          .setColor('#000100')
          .setTitle('**القوانين**')
          .setDescription(`**لرؤية قوانين السيرفر اختار قوانين السيرفر
  لرؤية قوانين البائعين اختار قوانين البائعين
  لرؤية قوانين الادارة اختار قونين الادارة
  لرؤية قوانين القضاة اختار قوانين القضاة
  لرؤية قوانين الوسطاء اختار قوانين الوسطاء**`)
            .setImage("https://media.discordapp.net/attachments/1213228582126747759/1216130657114259546/image_26.png?ex=6611b9ef&is=65ff44ef&hm=bc02b235955a8d31f1375b36eb9975acaac012eee96173bce511a548cdbdb678&")
          .setAuthor({
            name: message.guild.name 
          })
            .setTimestamp();
          const rules = new StringSelectMenuBuilder()
          .setCustomId('rules')
          .setPlaceholder('اختار هنا')
        .addOptions(
          new StringSelectMenuOptionBuilder()
          .setLabel('قوانين السيرفر')
          .setValue('rules_server'),
          new StringSelectMenuOptionBuilder()
          .setLabel('قوانين البائعين')
          .setValue('rules_seller'),
          new StringSelectMenuOptionBuilder()
          .setLabel('قوانين الادارة')
          .setValue('rules_admin'),
          new StringSelectMenuOptionBuilder()
          .setLabel('قوانين القضاة')
          .setValue('rules_law'),
          new StringSelectMenuOptionBuilder()
          .setLabel('قوانين الوسطاء')
          .setValue('rules_staff')
        );
          const row = new ActionRowBuilder()
          .addComponents(rules);
          message.channel.send({ embeds: [embed], components: [row] });
     } catch (error) {
            console.error(error);
            message.reply('There was an error while executing this command!');
     }
  },
};