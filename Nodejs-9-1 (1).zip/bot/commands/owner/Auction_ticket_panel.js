const { EmbedBuilder, ApplicationCommandOptionType , Events , ActionRowBuilder , ButtonBuilder ,MessageAttachment, ButtonStyle , Message, TextInputStyle,TextInputBuilder,ModalBuilder, StringSelectMenuBuilder, StringSelectMenuOptionBuilder, PermissionsBitField } = require("discord.js");
module.exports = {
    name: "auction_panel",
    aliases: [],
    owners: true,
    async execute(client, message, args) {
        try {
            const auction = new StringSelectMenuBuilder()
            .setCustomId('auction')
            .setPlaceholder('طلب مزاد')
            .addOptions(
            new StringSelectMenuOptionBuilder()
            .setLabel('طلب مزاد')
            .setValue('auction_1'),
            );
            const row = new ActionRowBuilder()
            .addComponents(auction);
            const embed = new EmbedBuilder()
            .setColor("#000100")
            .setDescription(`**شـروط الـمـزاد | RedBull S  Rules
> #1 - لعرض مزادك افتح تيكت
> #2 - ممنوع السوالف او اي شي ثاني غير سىعرك
> #3 - ممنوع تقول غالي او مايستاهل
> #4 - ممنوع المزايده اقل من 10K
> #5 - البنك ممنوع إلا لو موجود بالسيرفر
> #6 - تحط سىعر و ما تشتري تاخذ بلاك ليست
> #7 - انعرض مزادك وجاك سىعر اقل من 30K تتعوض بمزاد مجاني
> #8 - التعويض مره واحده فقط
> #9 - اذا كنت ناسخ منشور السلعة من شخص اخر و جاء عليك بلاغ انه منسوخ سوف يتم مخالفتك و ممكن توصل الى بلاك ليست دائم
تـوقـيـت الـمـزاد
 المزاد النهارى 3:00 بتوقيت السعوديه و العراق و 2 بتوقيت مصر 
المزاد الليلى  8:00 بتوقيت السعوديه و العراق و 7 بتوقيت مصر
اسـىـعـار الـمـزاد
سىىعر المزاد في يوم الجمعة “ 30K “ 
سىىعر المزاد بباقي الايام “ 15K “
تـحـويـل الـمزاد
 فقط 
اذا قمت بالتحويل لشخص اخر فنحن لا نتحمل المسؤولية حتى لو اداري قال لك حول للشخص ده
اذا قمت بالتحويل خارج التذكرة فنحن لا نتحمل المسؤولية و لن يتم تعويضك**`)
            .setImage("https://media.discordapp.net/attachments/1221887365182914570/1221887503141703780/20240325_211503.png?ex=661d70ea&is=660afbea&hm=0cd74559f1920d3ee49b25c84614a6acb014d135bc2c658b711f19fa0a7966c8&")
              .setAuthor({
                name: message.guild.name,
                iconURL: message.guild.iconURL()
                })
                .setFooter({
                text: message.guild.name,
                iconURL: message.guild.iconURL()
                })
                .setThumbnail(message.guild.iconURL())
                .setTimestamp();
            message.channel.send({ embeds: [embed], components: [row] });
        } catch (error) {
            console.error(error);
            message.reply('There was an error while executing this command!');
        }
    },
};