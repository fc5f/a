const { EmbedBuilder, ButtonStyle, ButtonBuilder, ActionRowBuilder } = require("discord.js");
module.exports = {
        name: "spin",
        aliases: [],
         owners: true,
         async execute(client, message, args) {
          try{
        const row = new ActionRowBuilder()
        .addComponents(
        new ButtonBuilder()
        .setCustomId('spin')
        .setLabel('Spin')
        .setStyle(ButtonStyle.Secondary)
        );
        const embed = new EmbedBuilder()
        .setColor('#000100')
        .setTitle('Spin')
        .setDescription(`**
        Click on the button below to spin the wheel
        **`)
        .setAuthor({
        name: message.guild.name,
        iconURL: message.guild.iconURL()})
        .setFooter({
        text: message.guild.name,
          iconURL: message.guild.iconURL()
        })
        
        .setThumbnail(message.guild.iconURL())
       .setTimestamp();
       message.channel.send({ embeds: [embed], components: [row] });
        } catch (error) {
            console.error(error);
            message.reply('There was an error while executing this command!');
  
        }
    },
};