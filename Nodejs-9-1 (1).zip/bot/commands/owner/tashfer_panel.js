const { EmbedBuilder, ButtonStyle, ButtonBuilder, ActionRowBuilder } = require("discord.js");
module.exports = {
        name: "تشفير",
        aliases: [],
         owners: true,
         async execute(client, message, args) {
          try{
        const row = new ActionRowBuilder()
        .addComponents(
        new ButtonBuilder()
        .setCustomId('tashfer')
        .setLabel('شفر منشورك الان')
        .setStyle(ButtonStyle.Secondary)
        );
        const embed = new EmbedBuilder()
        .setColor('#000100')
        .setTitle('تشفير منشورك')
        .setDescription(`**لتشفير منشورك يرجى ضغط علي الزر وضع منشورك**`)
          .setImage("https://media.discordapp.net/attachments/1213228582126747759/1216124910032912435/image_12.png?ex=6611b495&is=65ff3f95&hm=c8b7b7a4decc91dce07cf5e2be96f0156bf6da3676288c251aa60c580e5279d5&")
        .setAuthor({
        name: message.guild.name,
        iconURL: message.guild.iconURL()})
        .setFooter({
        text: message.guild.name,
          iconURL: message.guild.iconURL()
        })
         
        .setThumbnail(message.guild.iconURL())
       .setTimestamp();
       message.channel.send({ embeds: [embed], components: [row] });
        } catch (error) {
            console.error(error);
            message.reply('There was an error while executing this command!');
     }
 },
};