const { EmbedBuilder, ButtonStyle, ButtonBuilder, ActionRowBuilder } = require("discord.js");
module.exports = {
        name: "apply-panel",
        aliases: [],
         owners: true,
         async execute(client, message, args) {
          try{
          const row = new ActionRowBuilder()
          .addComponents(
            new ButtonBuilder()
            .setCustomId('support_apply')
            .setLabel('تقديم اداره')
            .setStyle(ButtonStyle.Secondary),
            new ButtonBuilder()
            .setCustomId("mediator_apply")
            .setLabel("تقديم وسطاء")
            .setStyle(ButtonStyle.Secondary),
            new ButtonBuilder()
            .setCustomId("report_apply")
            .setLabel('تقديم قضاه')
            .setStyle(ButtonStyle.Secondary)
          );
          const embed = new EmbedBuilder()
          .setColor('#000100')
          .setTitle('تقديم على ادارة سيرفر ريدبول')
          .setDescription(`
- يوجد للادارة رواتب ( 2500 كريدت على كل تكت - 1500 كريدت على كل تحذير )
- يوجد للقضاة رواتب ( 4000 كريدت على كل تكت )
- يوجد للوسطاء نسبة ( 5% ) من المبلغ التوسط ( تاخده من الي فتحوا التكت.. )
- الشعار للقضاة و الادارة اجباري و ليس اختياري 
- الضمان للتقديم على الوسيط اجباري و ليس اختياري ( الضمان ما يرجع في حالة الاستقالة - الفصال )
- مبالغ الضمانات للوسطاء :

وسيط 1 = 450k
وسيط 2 = 1.05m
وسيط 3 = 2.5m

- رتبة بيـع خاصة لطاقم الادارة طول فترة تواجدك 
- منشورات مميزة كل ما زاد تفاعلك 
- رتبه افضل اداري اسبوعيا..`)
          .setAuthor({
            name: message.guild.name,
            iconURL: message.guild.iconURL()
          })
          .setFooter({
            text: message.guild.name,
            iconURL: message.guild.iconURL()
          })
          .setThumbnail(message.guild.iconURL())
          .setImage('https://media.discordapp.net/attachments/1221887365182914570/1221887507860553819/20240325_204633.png?ex=661d70eb&is=660afbeb&hm=ebe6615f1a5b3c1d994de5c08218fcbfc808ffd86426799f6275170d8759bbc6&')
          .setTimestamp();
          message.channel.send({ embeds: [embed], components: [row] });
       } catch (error) {
            console.error(error);
            message.reply('There was an error while executing this command!');
   
       }
   },
};