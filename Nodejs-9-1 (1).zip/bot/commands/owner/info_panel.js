const { EmbedBuilder, ApplicationCommandOptionType , Events , ActionRowBuilder , ButtonBuilder ,MessageAttachment, ButtonStyle , Message, TextInputStyle,TextInputBuilder,ModalBuilder, StringSelectMenuBuilder, StringSelectMenuOptionBuilder, PermissionsBitField } = require("discord.js");


  module.exports = {
    name: "info",
    aliases: [],
    owners: true,
    async execute(client, message, args) {
        try{
          
          const embed = new EmbedBuilder()
          .setColor('#000100')
          .setTitle('المعلومات')
          .setDescription(`**لرؤية معلومات الرتب العامة اختار الرتب العامة
  لرؤية معلومات الرتب النادرة اختار الرتب النادرة 
  لرؤية معلومات الاعلانات اختار الاعلانات
  لرؤية معلومات المنشورات المميزة اختار المنشورات المميزة
  لرؤية معلومات الاضافات اختار الاضافات
  لرؤية  الاسئلة الشائعة اختار الاسئلة الشائعة**`)
            .setImage("https://media.discordapp.net/attachments/1213228582126747759/1216130525245210715/image_19.png?ex=6611b9cf&is=65ff44cf&hm=3308862043697d90f431d6a377713e1fb80bb354968d4e47e3aeacb70a6e4d65&")
          .setAuthor({
            name: message.guild.name 
          })
            .setTimestamp();
          const info = new StringSelectMenuBuilder()
          .setCustomId('info')
          .setPlaceholder('اختار هنا')
          .addOptions(
          new StringSelectMenuOptionBuilder()
          .setLabel('الرتب العامة')
          .setValue('info_roles'),
          new StringSelectMenuOptionBuilder()
          .setLabel('الرومات الخاصة')
          .setValue('info_room'),
          new StringSelectMenuOptionBuilder()
          .setLabel('الاعلانات')
          .setValue('info_ads'),
          new StringSelectMenuOptionBuilder()
          .setLabel('المنشورات المميزة')
          .setValue('info_manshort'),
          new StringSelectMenuOptionBuilder()
          .setLabel('الاضافات')
          .setValue('info_add'),
          new StringSelectMenuOptionBuilder()
          .setLabel('الاسئلة الشائعة')
          .setValue('info_q')
          );
          const row = new ActionRowBuilder()
            .addComponents(info);
          message.channel.send({ embeds: [embed], components: [row] });
        
        } catch (error) {
            console.error(error);
            message.reply('There was an error while executing this command!');
        }
    },
};