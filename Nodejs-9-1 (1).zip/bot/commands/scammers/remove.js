const { EmbedBuilder } = require('discord.js');
const scammers = require('../../Datebase/model/scammers.js');
module.exports = {
  name: 'remove',
  description: 'Remove a user from the scammer list.',
  aliases: [],
  owners: true,
  async execute(client, message, args) {
    try{
    const user = message.mentions.users.first() || message.guild.members.cache.get(args[0]);
    if (!user) {
      return message.reply('Please mention a user or provide a user ID.');
    }
    const scammer = await scammers.findOne({ guildID: message.guild.id, userID: user.id });
    if (!scammer) {
      return message.reply('This user is not in the scammer list.');
    }
      const scammerr = await scammers.deleteOne({ guildID: message.guild.id, userID: user.id });
    const embed = new EmbedBuilder()
      .setTitle("تم حذف الشخص من قائمة النصابين")
      .setDescription(`**الشخص الذي تم حذفه من قائمة النصابين : <@${user.id}>**`)
      .setColor('#000100');
    message.channel.send({ embeds: [embed] });
    } catch (err) {
            console.log(err);
        }
  },
};
