const { EmbedBuilder } = require('discord.js');
const scammers = require('../../Datebase/model/scammers.js');
module.exports = {
  name: 'add',
  description: 'Add a user to the scammer list.',
  aliases: [],
  owners: true,
  async execute(client, message, args) {
    try{
    const user = message.mentions.users.first() || message.guild.members.cache.get(args[0]);
    if (!user) {
      return message.reply('Please mention a user or provide a user ID.');
    }

    const reason = args.slice(1).join(' ');
    if (!reason) {
      return message.reply('Please provide a reason for adding the user to the scammer list.');
    }

    const scammer = await scammers.findOne({ guildID: message.guild.id, userID: user.id });
    if (scammer) {
      return message.reply('This user is already in the scammer list.');
    }

    const newScammer = new scammers({
      guildID: message.guild.id,
      userID: user.id,
      username: user.username,
      reason: reason,
      time: Date.now(),
    });

    await newScammer.save();
    const embed = new EmbedBuilder()
      .setTitle("تم اضافة الشخص الي قائمة النصابين")
      .setDescription(
        `**الشخص الذي تم اضافته الي قائمة النصابين : ${user.tag}**\n**السبب : ${reason}**`)
      .setColor('#000100');
    message.channel.send({ embeds: [embed] });
    } catch (err) {
            console.log(err);
        }
    },
};