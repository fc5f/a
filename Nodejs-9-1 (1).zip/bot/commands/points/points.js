const { EmbedBuilder } = require("discord.js")
const points = require('../../Datebase/model/points.js');
const config = require('../../config.json');

module.exports = {
    name: 'points',
    description: 'لرؤية نقاطك',
    aliases: [],
    async execute(client, message, args) {
        try { 
          if (!message.member.roles.cache.has(config.staff)) return;

        let user = message.mentions.users.first();
        if (user) {
          let member = message.guild.members.cache.find((u) => u == user.id);
                                  const data = await points.findOne({ guildId: message.guild.id, userId: user.id });
            if (!data) {
                return message.reply({ content: `لا يوجد لديك نقاط`, ephemeral: true });
            }
          const embed = new EmbedBuilder()
          .setColor('#000100')
          .setTitle(`${user.username}, points`)
          .setDescription(`** > - All Points: ${data.points}**`)
            .setAuthor({
          name: message.guild.name,
          iconURL: message.guild.iconURL()})
            .setFooter({
    text: user.username,
      iconURL: user.displayAvatarURL() 
    })
.setThumbnail(message.guild.iconURL())
          .setTimestamp();
          message.reply({ embeds: [embed], ephemeral: true });
            
          }

        if (!user) {
          const data = await points.findOne({ guildId: message.guild.id, userId: message.author.id });
            if (!data) {
                return message.reply({ content: `لا يوجد لديك نقاط`, ephemeral: true });
            }
          const embed = new EmbedBuilder()
                      .setColor('#000100')
                      .setTitle(`${message.author.username}, points`)
          .setDescription(`** > - All Points: ${data.points}**`)
          .setAuthor({
            name: message.guild.name,
            iconURL: message.guild.iconURL()})
            .setFooter({
            text: message.author.username,
              iconURL: message.author.displayAvatarURL() 
            })
          .setThumbnail(message.guild.iconURL())
                  .setTimestamp();
          message.reply({ embeds: [embed], ephemeral: true });
        }
        } catch (err) {
            console.log(err);
        }
    },
};