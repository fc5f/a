const { EmbedBuilder } = require("discord.js");
const points = require('../../Datebase/model/points.js');
const config = require('../../config.json');
module.exports = {
    name: 'add',
    description: 'لأضافة نقاط لشخص',
    aliases: [],
    async execute(client, message, args) {
        try{
            if (!message.member.roles.cache.has(config.staff)) return;
            const member = message.mentions.members.first() || message.guild.members.cache.get(args[0]);
            if (!member) return message.reply({ content: `**يرجى تحديد العضو**` });
            const amount = parseInt(args[1]);
            if (!amount || isNaN(amount)) return message.reply({ content: `**يرجى تحديد العدد الصحيح**` });
            const data = await points.findOne({ guildId: message.guild.id, userId: member.id });
            if (!data) {
                await points.create({
                    guildId: message.guild.id,
                    userId: member.id,
                    points: amount
                });
            } else {
                data.points += amount;
                await data.save();
            }
            const embed = new EmbedBuilder()
                .setColor('#000100')
                .setTitle(`**تمت العملية بنجاح**`)
                .setDescription(`**تمت إضافة ${amount} نقطة لـ ${member} **`)
                .setAuthor({
                    name: message.guild.name,
                    iconURL: message.guild.iconURL()
                })
                .setFooter({
                    text: message.author.username,
                    iconURL: message.author.displayAvatarURL()
                })
                .setThumbnail(message.guild.iconURL())
                .setTimestamp();
            message.reply({ embeds: [embed] });
          
        } catch (err) {
            console.log(err);
        }
    },
};