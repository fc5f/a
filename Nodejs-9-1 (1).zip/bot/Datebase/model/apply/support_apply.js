const Mongoose = require('mongoose');
const supportSchema = new Mongoose.Schema({
  guildId: {
    type: String,
    required: true,
  },
  userId: {
    type: String,
    required: true,
  }
});
module.exports = Mongoose.model('support_apply', supportSchema);