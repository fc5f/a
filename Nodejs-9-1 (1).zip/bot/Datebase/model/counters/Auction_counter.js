const Mongoose = require('mongoose');
const AuctionSchema = new Mongoose.Schema({
guildId: {
    type: String,
    required: false,
  },
  counter: {
    type: Number,
    default: 0,
  },
});
module.exports = Mongoose.model('Auction', AuctionSchema);