const mongoose = require('mongoose');
const PrivateRoomSchema = new mongoose.Schema({
  guildId: {
    type: String,
    required: true,
  },
  channelId: {
    type: String,
    required: true,
  },
  ownerId: {
    type: String,
    required: true,
  },
  Privatecount: {
    type: Number,
    default: 0,
  },
  time: {
    type: Number,
    required: true,
  },
  createdAt: {
    type: Date,
    required: true,
    default: Date.now,
  },
  endAt: {
    type: Date,
    required: true,
  }
});
module.exports = mongoose.model('PrivateRoom', PrivateRoomSchema);