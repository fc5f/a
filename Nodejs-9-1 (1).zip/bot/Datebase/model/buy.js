const Mongoose = require('mongoose');

const buySchema = new Mongoose.Schema(
  {
    userId: {
      type: String,
      required: true,
    },
    buy: {
      type: Boolean,
      required: true,
    }
  },
);
module.exports = Mongoose.model('buy', buySchema);