const mongoose = require('mongoose');
const scammers = new mongoose.Schema(
  {
    guildID: { type: String, required: true },
    userID: { type: String, required: true },
    username: { type: String, required: false },
    reason: { type: String, required: true },
    time: { type: Number, required: true },

  });
module.exports = mongoose.model('scammers', scammers);