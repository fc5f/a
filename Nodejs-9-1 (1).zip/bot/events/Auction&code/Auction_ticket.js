const client = require("../../index.js");
const { EmbedBuilder, ActionRowBuilder , ButtonBuilder , ButtonStyle, TextInputStyle,TextInputBuilder,ModalBuilder } = require("discord.js");
const counters = require('../../Datebase/model/counters/Auction_counter.js');
client.on('interactionCreate', async interaction => {
  if (!interaction.isStringSelectMenu()) return;
  if (interaction.customId === 'auction') {
    const selectedValue = interaction.values[0];
    if (selectedValue === 'auction_1') {
      const counter = await counters.updateOne(
      { guildId: interaction.guild.id },
      { $inc: { counter: 1 } },
      { upsert: true }
    );

    const findCount = await counters.findOne({ guildId: interaction.guild.id });

      const ctr = findCount.counter
      const auction = await
interaction.guild.channels.create({
        name: `auction-${ctr}`,
        type: 0,
        parent: '1224721523944980690',
        permissionOverwrites: [
          {
            id: interaction.guild.id,
            deny: ['ViewChannel'],
          },
          {
            id: interaction.user.id,
            allow: ['ViewChannel'],
          },
         {
            id: "1224829322926227640",
            allow: ['ViewChannel'],
          },
        ],
      });
          await interaction.reply({
              content: `تم إنشاء تذكرتك في ${auction}`,
              ephemeral: true,
            });
          const row = new ActionRowBuilder()
          .addComponents(
            new ButtonBuilder()
              .setCustomId('auction_buy')
              .setLabel('شراء مزاد')
              .setStyle(ButtonStyle.Secondary),
            new ButtonBuilder()
              .setCustomId("auction_claim")
              .setLabel("استلام التذكره")
              .setStyle(ButtonStyle.Secondary),
            new ButtonBuilder()
              .setCustomId("auction_help")
              .setLabel("مساعده طاقم المزاد")
              .setStyle(ButtonStyle.Secondary),
            new ButtonBuilder()
              .setCustomId("auction_delete_ticket")
              .setLabel("حذف التذكره")
              .setStyle(ButtonStyle.Danger)
          );
        const embed = new EmbedBuilder()
          .setColor("#000100")
          .setDescription(`**

نحتاج منك ملء النموذج:

                    


-  السلعة : 
- بداية المزايدة '30k' ، '10k' :
- : @ 


- اذا كان 7ساب ديسكورد عبي :


- عمر الـ7ـساب 
- سمعة الـ7ـساب 
- مستوى الـ7ـساب ( في بروبوت ) 
- مفعل نيتر9 قبل او لا؟
- صورة للـ7ـساب : 


- اذا كان سيرفر ديسكورد عبي هذا النموذج :


- عدد أعضاء السيرفر
- نوع السيرفر (كوميونتي، شـ9ب، الخ)
- عمر السيرفر
- كم توكن فيه
- معدل تفاعل السيرفر**`)
          .setImage("https://media.discordapp.net/attachments/1221887365182914570/1221887503141703780/20240325_211503.png?ex=661d70ea&is=660afbea&hm=0cd74559f1920d3ee49b25c84614a6acb014d135bc2c658b711f19fa0a7966c8&")
          .setAuthor({
            name: interaction.guild.name,
            iconURL: interaction.guild.iconURL()
          })
          .setFooter({
            text: interaction.guild.name,
            iconURL: interaction.guild.iconURL()
          })
          .setThumbnail(interaction.guild.iconURL());
        await auction.send({
                  content: `${interaction.user}||<@&1224829322926227640>`,
          components: [row],
          embeds: [embed],
        });
    }
  }
});