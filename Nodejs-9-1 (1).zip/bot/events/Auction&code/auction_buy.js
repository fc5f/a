const client = require("../../index.js");
const { EmbedBuilder, ApplicationCommandOptionType , Events , ActionRowBuilder , ButtonBuilder ,MessageAttachment, ButtonStyle , Message, TextInputStyle,TextInputBuilder,ModalBuilder, StringSelectMenuBuilder, StringSelectMenuOptionBuilder, PermissionsBitField } = require("discord.js");
const config = require("../../config.json");
client.on('interactionCreate', async interaction => {
  if (!interaction.isButton()) return;
  if (interaction.customId === 'auction_buy') {
    const auction_buy = new StringSelectMenuBuilder()
    .setCustomId("auction_buy1")
    .setPlaceholder("اختار نوع المزاد")
    .addOptions(
      new StringSelectMenuOptionBuilder()
      .setLabel('مزاد عادي')
      .setValue('auction_buy_normal'),
      new StringSelectMenuOptionBuilder()
      .setLabel("مزاد نادر")
      .setValue("auction_buy_rare"),
      new StringSelectMenuOptionBuilder()
      .setLabel("مزاد ملكي")
      .setValue("auction_buy_epic"),
    );
    const row = new ActionRowBuilder()
    .addComponents(auction_buy);
    const embed = new EmbedBuilder()
    .setColor("#000100")
    .setDescription("**- اهلا وسهلا في مزادات **");
    await interaction.reply({
      components: [row],
      embeds: [embed],
    })
  }
});
client.on('interactionCreate', async interaction => {
  if (!interaction.isStringSelectMenu()) return;
  if (interaction.customId === 'auction_buy1') {
    const selectedValue = interaction.values[0];
    if (selectedValue === 'auction_buy_normal') {
      let price = "1";
        let result = price;
  let tax = Math.floor(price * (20 / 19) + 1);
  let owner = config.owner;
      const embed = new EmbedBuilder()
      .setTitle("مزاد عادي")
      .setDescription(
        `**- قم بتحويل مبلغ \`${result}\` إلى <@${owner}>**`);
      await interaction.update({
        embeds: [embed],
        components: [],
      })
      await interaction.channel.send({
      content: `#credit ${owner} ${tax}`
    })
      const filter = ({ content, author: { id } }) => {
        return (
            content.startsWith(`**:moneybag: | ${interaction.user.username}, has transferred `) &&
            content.includes(`${owner}`) &&
            id === "282859044593598464" &&
            (Number(content.slice(content.lastIndexOf("`") - String(tax).length, content.lastIndexOf("`"))) >= result)
        );
    };

      const collector = interaction.channel.createMessageCollector({ 
        filter,               
        max: 1,
        time: 60000,
        });
        let iscollected = false;
        collector.on('collect', async (collected) => {
        iscollected = true;
        const embed = new EmbedBuilder()
      .setTitle(
        "شراء مزاد عادي")
      .setDescription(
        `**تم شراء مزاد عادي بنجاح**`);
      const a = new ActionRowBuilder()
    .addComponents(
      new ButtonBuilder()
        .setCustomId('auction_done')
        .setLabel('قم بوضع مزادك هنا')
        .setStyle(ButtonStyle.Success)
    );
  await interaction.editReply({
    embeds: [embed],
    components: [a],
  })
  const log = client.channels.cache.get(config.log)
  const logembed = new EmbedBuilder()
  .setColor('#000100')
  .setTitle("شراء مزاد عادي")
  .addFields(
   {
     name: "تم شراء بواسطة",
     value: `<@${interaction.member.id}>`,
     inline: true
   },
   {
     name: "نوع المزاد",
     value: `مزاد عادي`,
     inline: true
   },
   {
     name: "المبلغ",
     value: `${result}`,
     inline: true
   }
  )
  .setThumbnail(interaction.guild.iconURL({dynamic:true}))
  .setTimestamp();
  await log.send({embeds:[logembed]})
});
      collector.on('end', async (collected) => {
  if (!iscollected) {
    const embed = new EmbedBuilder()
    .setColor('#000100')
    .setDescription(`**انتهى وقت العمليه**`)
    .setTimestamp();
    await interaction.editReply({
    embeds: [embed],
    components: [],
    })
    }
    });
    } else if (selectedValue === 'auction_buy_rare') {
      let price = "1";
      let result = price;
    let tax = Math.floor(price * (20 / 19) + 1);
  let owner = config.owner;
      const embed = new EmbedBuilder()
      .setTitle("مزاد نادر")
      .setDescription(
        `**- قم بتحويل مبلغ \`${result}\` إلى <@${owner}>**`);
      await interaction.update({
        embeds: [embed],
        components: [],
      })
      await interaction.channel.send({
      content: `#credit ${owner} ${tax}`
    })
      const filter = ({ content, author: { id } }) => {
        return (
            content.startsWith(`**:moneybag: | ${interaction.user.username}, has transferred `) &&
            content.includes(`${owner}`) &&
            id === "282859044593598464" &&
            (Number(content.slice(content.lastIndexOf("`") - String(tax).length, content.lastIndexOf("`"))) >= result)
        );
    };

      const collector = interaction.channel.createMessageCollector({ 
        filter,               
        max: 1,
        time: 60000,
        });
        let iscollected = false;
        collector.on('collect', async (collected) => {
        iscollected = true;
        const embed = new EmbedBuilder()
      .setTitle(
        "شراء مزاد نادر")
      .setDescription(
        `**تم شراء نادر عادي بنجاح**`);
      const a = new ActionRowBuilder()
    .addComponents(
      new ButtonBuilder()
        .setCustomId('auction_done_rare')
        .setLabel('قم بوضع مزادك هنا')
        .setStyle(ButtonStyle.Success)
    );
  await interaction.editReply({
    embeds: [embed],
    components: [a],
  })
  const log = client.channels.cache.get(config.log)
  const logembed = new EmbedBuilder()
  .setColor('#000100')
  .setTitle("شراء مزاد نادر")
  .addFields(
   {
     name: "تم شراء بواسطة",
     value: `<@${interaction.member.id}>`,
     inline: true
   },
   {
     name: "نوع المزاد",
     value: `مزاد نادر`,
     inline: true
   },
   {
     name: "المبلغ",
     value: `${result}`,
     inline: true
   }
  )
  .setThumbnail(interaction.guild.iconURL({dynamic:true}))
  .setTimestamp();
  await log.send({embeds:[logembed]})
});
      collector.on('end', async (collected) => {
  if (!iscollected) {
    const embed = new EmbedBuilder()
    .setColor('#000100')
    .setDescription(`**انتهى وقت العمليه**`)
    .setTimestamp();
    await interaction.editReply({
    embeds: [embed],
    components: [],
    })
    }
    });
      
    } else if (selectedValue === 'auction_buy_epic') {
      let price = "1";
      let result = price;
    let tax = Math.floor(price * (20 / 19) + 1);
  let owner = config.owner;
      const embed = new EmbedBuilder()
      .setTitle("مزاد ملكي")
      .setDescription(
        `**- قم بتحويل مبلغ \`${result}\` إلى <@${owner}>**`);
      await interaction.update({
        embeds: [embed],
        components: [],
      })
      await interaction.channel.send({
      content: `#credit ${owner} ${tax}`
    })
      const filter = ({ content, author: { id } }) => {
        return (
            content.startsWith(`**:moneybag: | ${interaction.user.username}, has transferred `) &&
            content.includes(`${owner}`) &&
            id === "282859044593598464" &&
            (Number(content.slice(content.lastIndexOf("`") - String(tax).length, content.lastIndexOf("`"))) >= result)
        );
    };
      const collector = interaction.channel.createMessageCollector({
        filter,               
        max: 1,
        time: 60000,
      });
      let iscollected = false;
      collector.on('collect', async (collected) => {
        iscollected = true;
        const embed = new EmbedBuilder()
      .setTitle(
        "شراء مزاد ملكي")
      .setDescription(
        `**تم شراء ملكي عادي بنجاح**`);
      const a = new ActionRowBuilder()
    .addComponents(
      new ButtonBuilder()
        .setCustomId('auction_done_epic')
        .setLabel('قم بوضع مزادك هنا')
        .setStyle(ButtonStyle.Success)
    );
  await interaction.editReply({
    embeds: [embed],
    components: [a],
  })
  const log = client.channels.cache.get(config.log)
  const logembed = new EmbedBuilder()
  .setColor('#000100')
  .setTitle("شراء مزاد ملكي")
          .addFields(
           {
             name: "تم شراء بواسطة",
             value: `<@${interaction.member.id}>`,
             inline: true
           },
           {
             name: "نوع المزاد",
             value: `مزاد نادر`,
             inline: true
           },
           {
             name: "المبلغ",
             value: `${result}`,
             inline: true
           }
          )
          .setThumbnail(interaction.guild.iconURL({dynamic:true}))
          .setTimestamp();
          await log.send({embeds:[logembed]})
      });
      collector.on('end', async (collected) => {
  if (!iscollected) {
    const embed = new EmbedBuilder()
    .setColor('#000100')
    .setDescription(`**انتهى وقت العمليه**`)
    .setTimestamp();
    await interaction.editReply({
    embeds: [embed],
    components: [],
    })
  }
    });
    }
  }
});
client.on('interactionCreate', async interaction => {
  if (!interaction.isButton()) return;
  if (interaction.customId === 'auction_done') {
    const modal = new ModalBuilder()
    .setCustomId('auction_done1')
    .setTitle('مزاد عادي')
    const a1 = new TextInputBuilder()
    .setCustomId('auction_item1')
    .setLabel("السلعه")
    .setStyle(TextInputStyle.Short)
    .setRequired(true);
    const a2 = new TextInputBuilder()
    .setCustomId('auction_item_descrtion1')
    .setLabel("وصف السلعه")
    .setStyle(TextInputStyle.Paragraph)
    .setRequired(true);
    const firstActionRow = new ActionRowBuilder().addComponents(a1)
    const secondActionRow = new ActionRowBuilder().addComponents(a2)
    modal.addComponents(firstActionRow, secondActionRow)
    await interaction.showModal(modal)
  } else if (interaction.customId === 'auction_done_rare') {
    const modal = new ModalBuilder()
    .setCustomId('auction_done2')
    .setTitle('مزاد نادر')
    const a1 = new TextInputBuilder()
    .setCustomId('auction_item2')
    .setLabel("السلعه")
    .setStyle(TextInputStyle.Short)
    .setRequired(true);
    const a2 = new TextInputBuilder()
    .setCustomId('auction_item_descrtion2')
    .setLabel("وصف السلعه")
    .setStyle(TextInputStyle.Paragraph)
    .setRequired(true);
    const firstActionRow = new ActionRowBuilder().addComponents(a1)
    const secondActionRow = new ActionRowBuilder().addComponents(a2)
    modal.addComponents(firstActionRow, secondActionRow)
    await interaction.showModal(modal)
  } else if (interaction.customId === 'auction_done_epic') {
    const modal = new ModalBuilder()
    .setCustomId('auction_done3')
    .setTitle('مزاد ملكي')
    const a1 = new TextInputBuilder()
    .setCustomId('auction_item3')
    .setLabel("السلعه")
    .setStyle(TextInputStyle.Short)
    .setRequired(true);
    const a2 = new TextInputBuilder()
    .setCustomId('auction_item_descrtion3')
    .setLabel("وصف السلعه")
    .setStyle(TextInputStyle.Paragraph)
    .setRequired(true);
    const firstActionRow = new ActionRowBuilder().addComponents(a1)
    const secondActionRow = new ActionRowBuilder().addComponents(a2)
    modal.addComponents(firstActionRow, secondActionRow)
    await interaction.showModal(modal)
  }
});
client.on('interactionCreate', async interaction => {
  if (!interaction.isModalSubmit()) return;
  if (interaction.customId === 'auction_done1') {
    const a1 = interaction.fields.getTextInputValue('auction_item1')
    const a2 = interaction.fields.getTextInputValue('auction_item_descrtion1')
    
    const Auction_items = interaction.guild.channels.cache.get(config.Auction_items_channel);
    const auction_done = new EmbedBuilder()
    .setColor('#000100')
    .setTitle("سـلـعــة الـيــوم")
    .addFields(
      {
        name: "السـلـعـة",
        value: `${a1}`,
        inline: true
      },
      {
        name: "وصـف الـسـلـعـة",
        value: `${a2}`,
        inline: true
      }
    )
      .setImage("https://media.discordapp.net/attachments/1221887365182914570/1221887502382792824/20240325_212004.png?ex=661d70ea&is=660afbea&hm=45273117b9597818475b1e3d3ecfcdfa21c43aae32d13c14b32aa14de62661ef&")
    .setThumbnail(interaction.guild.iconURL({dynamic:true}))
    .setTimestamp();
    const row = new ActionRowBuilder()
    .addComponents(
      new ButtonBuilder()
        .setCustomId('post_item')
        .setLabel('نشر السلعة')
      .setEmoji('<:emoji_23:1223097952663244851>')
        .setStyle(ButtonStyle.Secondary),
      new ButtonBuilder()
        .setCustomId('cancle_item')
        .setLabel('حذف السلعه')
      .setEmoji('<:emoji_23:1223097930731491360>')
        .setStyle(ButtonStyle.Secondary)
    );
    await interaction.reply({
      content: `**تم وصول السلعه انتظر حتا يتم نشرها من قبل الإدارة**`,
      ephemeral: true,
    })
    await Auction_items.send({
      components: [row],
      embeds: [auction_done],
    });
  } else if (interaction.customId === 'auction_done2') {
    const a1 = interaction.fields.getTextInputValue('auction_item2')
    const a2 = interaction.fields.getTextInputValue('auction_item_descrtion2')
    const Auction_items = interaction.guild.channels.cache.get(config.Auction_items_channel);
    const auction_done = new EmbedBuilder()
    .setColor('#000100')
    .setTitle("سـلـعــة الـيــوم")
    .addFields(
      {
        name: "السـلـعـة",
        value: `${a1}`,
        inline: true
      },
      {
        name: "وصـف الـسـلـعـة",
        value: `${a2}`,
        inline: true
      }
    )
      .setImage("https://media.discordapp.net/attachments/1221887365182914570/1221887502382792824/20240325_212004.png?ex=661d70ea&is=660afbea&hm=45273117b9597818475b1e3d3ecfcdfa21c43aae32d13c14b32aa14de62661ef&")
    .setThumbnail(interaction.guild.iconURL({dynamic:true}))
    .setTimestamp();
    const row = new ActionRowBuilder()
    .addComponents(
      new ButtonBuilder()
        .setCustomId('post_item')
        .setLabel('نشر السلعة')
      .setEmoji('<:emoji_23:1223097952663244851>')
        .setStyle(ButtonStyle.Secondary),
      new ButtonBuilder()
        .setCustomId('cancle_item')
        .setLabel('حذف السلعه')
      .setEmoji('<:emoji_23:1223097930731491360>')
        .setStyle(ButtonStyle.Secondary)
    );
    await interaction.reply({
      content: `**تم وصول السلعه انتظر حتا يتم نشرها من قبل الإدارة**`,
      ephemeral: true,
    })
    await Auction_items.send({
      components: [row],
      embeds: [auction_done],
    });
  } else if (interaction.customId === 'auction_done3') {
    const a1 = interaction.fields.getTextInputValue('auction_item3')
    const a2 = interaction.fields.getTextInputValue('auction_item_descrtion3')
    const Auction_items = interaction.guild.channels.cache.get(config.Auction_items_channel);
    const auction_done = new EmbedBuilder()
    .setColor('#000100')
    .setTitle("سـلـعــة الـيــوم")
    .addFields(
      {
        name: "السـلـعـة",
        value: `${a1}`,
        inline: true
      },
      {
        name: "وصـف الـسـلـعـة",
        value: `${a2}`,
        inline: true
      }
    )
      .setImage("https://media.discordapp.net/attachments/1221887365182914570/1221887502382792824/20240325_212004.png?ex=661d70ea&is=660afbea&hm=45273117b9597818475b1e3d3ecfcdfa21c43aae32d13c14b32aa14de62661ef&")
    .setThumbnail(interaction.guild.iconURL({dynamic:true}))
    .setTimestamp();
    const row = new ActionRowBuilder()
    .addComponents(
      new ButtonBuilder()
        .setCustomId('post_item')
        .setLabel('نشر السلعة')
      .setEmoji('<:emoji_23:1223097952663244851>')
        .setStyle(ButtonStyle.Secondary),
      new ButtonBuilder()
        .setCustomId('cancle_item')
        .setLabel('حذف السلعه')
      .setEmoji('<:emoji_23:1223097930731491360>')
        .setStyle(ButtonStyle.Secondary)
    );
    await interaction.reply({
      content: `**تم وصول السلعه انتظر حتا يتم نشرها من قبل الإدارة**`,
      ephemeral: true,
    })
    await Auction_items.send({
      components: [row],
      embeds: [auction_done],
    });
  }
});
