const client = require("../../index.js");

const config = require("../../config.json");
const { TextInputStyle,TextInputBuilder,ModalBuilder, ActionRowBuilder, EmbedBuilder  } = require("discord.js");

replace = [
  {
    word: "ديسكورد",
    replace: "ديـ-ـكورد"
  },
   {
    word: "متجر",
    replace: ""
  }, 
    {
    word: "شوب",
    replace: "شـ9ب"
  },  
  {
      word: "متوفر",
      replace: "مـtوفر"
  },
{
    word: "بوست",
    replace: "بو-ـت"
  },
{
    word: "نيترو",
    replace: "نيـ-ـرو"
  },
{
    word: "حساب",
    replace: "حـ-ـاب"
  },
{
    word: "سيرفر",
    replace: "سـ-ـرفر"
  },
{
    word: "سعر",
    replace: "سـ-ـر"
  },
   {
    word: "شراء",
    replace: "شـ-اء"
  },
   {
     word: "نصاب",
    replace: "نـ-ـاب"
   },
   {
    word: "بيع",
    replace: "بـ-ـع"
  },
   {
         word: "الديسكورد",
    replace: "الديـ-ـكورد"
  },
  {
    word: "المتجر",
    replace: "المـ-ـجر"
  }, 
  {
    word: "الشوب",
    replace: "الشـ-ـب"
  },  
  {
      word: "المتوفر",
      replace: "المـ-ـوفر"
  },
{
    word: "البوست",
    replace: "البو-ـت"
  },
{
    word: "النيترو",
    replace: "النيـ-ـرو"
  },
{
    word: "الحساب",
    replace: "الحـ-ـاب"
  },
{
    word: "السيرفر",
    replace: "السـ-ـرفر"
  },
{
    word: "السعر",
    replace: "السـ-ـر"
  },
   {
    word: "الشراء",
    replace: "الشـ-اء"
  },
   {
     word: "النصاب",
    replace: "النـ-ـاب"
   },
   {
    word: "البيع",
    replace: "البـ-ـع"
  },
]

client.on('interactionCreate', async interaction => {
  if (!interaction.isButton()) return;
  if (interaction.customId === 'tashfer') {
    const modal = new ModalBuilder()
      .setCustomId('tashferModal')
      .setTitle('تشفير منشورك');
    const tashferInput = new TextInputBuilder()
      .setCustomId('tashferInput')
      .setLabel('شفر منشورك')
      .setPlaceholder('اكتب منشورك هنا')
.setStyle(TextInputStyle.Paragraph)
      .setRequired(true);
    const firstActionRow = new ActionRowBuilder().addComponents(tashferInput);
    modal.addComponents(firstActionRow);
    await interaction.showModal(modal);
  }
});
client.on('interactionCreate', async interaction => {
if (!interaction.isModalSubmit()) return;
if (interaction.customId === 'tashferModal') {
let text = interaction.fields.getTextInputValue('tashferInput');
let rep = interaction.fields.getTextInputValue('tashferInput');

     let replaced = false;
    replace.forEach(t => {
      const regex = new RegExp(t.word, 'g');
      if (regex.test(text)) {
        text = text.replace(regex, t.replace);
        replaced = true;
      }
    });
    if (replaced) {
      await interaction.reply({ content: `\`منشورك بعد التشفير\`\n\n${text}`, ephemeral: true });
      let log = client.channels.cache.get(config.log)

       const log1 = new EmbedBuilder()
      .setTitle(`تشفير منشور جديد`)
        .addFields(
          {
            name: `المنشور قبل التشفير :`,
            value: `${rep}`
          },
          {
            name: `المنشور بعد التشفير :`,
            value: `${text}`
          },
          {
            name: `الشخص الذي قام بالتشفير :`,
            value: `${interaction.user}`
          }
        )
          .setColor("#000100")
      .setThumbnail(interaction.guild.iconURL({dynamic:true}))
          .setTimestamp();
          log.send({embeds:[log1]});
    } else {
      await interaction.reply({ content: 'لم يتم العثور على كلمة للتشفير', ephemeral: true });
    }
}
});