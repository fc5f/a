const client = require("../../index.js");
const { EmbedBuilder, ApplicationCommandOptionType , Events , ActionRowBuilder , ButtonBuilder ,MessageAttachment, ButtonStyle , Message, TextInputStyle,TextInputBuilder,ModalBuilder, StringSelectMenuBuilder, StringSelectMenuOptionBuilder, PermissionsBitField } = require("discord.js");
const config = require("../../config.json");

client.on(Events.InteractionCreate, async interaction => {
    if (!interaction.isStringSelectMenu()) return;
    if (interaction.customId === 'rules') {
        if (interaction.values[0] === 'rules_server') {
            const embed = new EmbedBuilder()
            .setColor('#000100')
            .setTitle('**__Server Rules・قوانين السيرفر__**')
            .setDescription(`**1 - احترام الجميع .
  2 - ممنوع طلب الرتب ، الرتب تمنح ولا تطلب .
  3 - يمنع الحديث بمواضيع السياسة والدينية .
  4 - ممنوع التكرار او السبام .
  5 - التقيد بقوانين ديسكـورد .
  
  “ https://discord.com/new/terms "**`);
          interaction.reply({ embeds: [embed], ephemeral: true })
        } else if (interaction.values[0] === 'rules_seller') {
          
          if (!interaction.member.roles.cache.has("1215951368339193944", "1215951368339193937")) return interaction.reply({ content: `**يجب ان تكون بائع عشان تشوف القوانين**`, ephemeral: true });
            const embed = new EmbedBuilder()
            .setColor("#000100")
            .setTitle('**__Seller Rules・قوانين البائع__**')
            .setDescription(
              `**1 - ممنوع طلب الرتب ، الرتب تمنح ولا تطلب .
  2 - يمنع التكرار او السبام .
  3 - يمنع التقيد بقوانين ديسكـورد .
  
  “ https://discord.com/new/terms "**`);
          interaction.reply({ embeds: [embed], ephemeral: true })
        
        } else if (interaction.values[0] === 'rules_admin') {
          
          if (!interaction.member.roles.cache.has('1215951368339193944')) return interaction.reply({ content: `**يجب ان تكون اداري عشان تشوف القوانين**`, ephemeral: true });
            const embed = new EmbedBuilder()
            .setColor("#000100")
            .setTitle('**__Admin Rules・قوانين الادارة__**')
              .setDescription(
                `**1 - ممنوع طلب الرتب ، الرتب تمنح ولا تطلب .
              2 - يمنع التكرار او السبام .
              3 - يمنع التقيد بقوانين ديسكـورد .

              “ https://discord.com/new/terms "**`);
            interaction.reply({ embeds: [embed], ephemeral: true })
        } else if (interaction.values[0] === 'rules_law') {
          if (!interaction.member.roles.cache.has('1215951368339193944')) return interaction.reply({ content: `**يجب ان تكون قاضي عشان تشوف القوانين**`, ephemeral: true });
            const embed = new EmbedBuilder()
            .setColor("#000100")
            .setTitle('**__Law Rules・قوانين القضاة__**')
              
        .setDescription(
              `**1 - ممنوع طلب الرتب ، الرتب تمنح ولا تطلب .
  2 - يمنع التكرار او السبام .
  3 - يمنع التقيد بقوانين ديسكـورد .
  
  “ https://discord.com/new/terms "**`);
          interaction.reply({ embeds: [embed], ephemeral: true })
          
        } else if (interaction.values[0] === 'rules_staff') {
          if (!interaction.member.roles.cache.has('1215951368339193944')) return interaction.reply({ content: `**يجب ان تكون وسيط عشان تشوف القوانين**`, ephemeral: true });
          const embed = new EmbedBuilder()
            .setColor("#000100")
            .setTitle('**__Law Rules・قوانين القضاة__**')
              
        .setDescription(
              `**1 - ممنوع طلب الرتب ، الرتب تمنح ولا تطلب .
  2 - يمنع التكرار او السبام .
  3 - يمنع التقيد بقوانين ديسكـورد .
  
  “ https://discord.com/new/terms "**`);
          interaction.reply({ embeds: [embed], ephemeral: true })
        }
    }
});