const client = require("../../index.js");
const db = require("pro.db");
const { EmbedBuilder, ApplicationCommandOptionType , Events , ActionRowBuilder , ButtonBuilder ,MessageAttachment, ButtonStyle , Message, TextInputStyle,TextInputBuilder,ModalBuilder, StringSelectMenuBuilder, StringSelectMenuOptionBuilder, PermissionsBitField } = require("discord.js");
const users = require('../../Datebase/model/buy.js');
client.on('interactionCreate', async interaction => {
  if (!interaction.isButton()) return;
  if (interaction.customId === 'buy') {

    const user = await users.findOne({ userId: interaction.user.id, buy: true });

if (user && user.buy === true) {
    return interaction.reply({ content: `**لديك عملية شراء بالفعل**`, ephemeral: true });
}

if (!user) {
    await users.create({ userId: interaction.user.id, buy: true });
} else {
    user.buy = true;
    await user.save();
} 

    const buy = new StringSelectMenuBuilder()
    .setCustomId('buy')
    .setPlaceholder('اختر نوع الشي')
    .addOptions(
      new StringSelectMenuOptionBuilder()
        .setLabel('شراء رتبه')
        .setValue('role'),
      new StringSelectMenuOptionBuilder()
        .setLabel('ازاله تحذيرات')
        .setValue('warn'),
      new StringSelectMenuOptionBuilder()
        .setLabel('شراء منشورات مميزة')
        .setValue('manshort'),
      new StringSelectMenuOptionBuilder()
        .setLabel('شراء روم خاص')
        .setValue('room'),
      new StringSelectMenuOptionBuilder()
        .setLabel('شراء اعلان')
        .setValue('ads'),
    );
    const row = new ActionRowBuilder()
      .addComponents(buy);
    const rd = new ActionRowBuilder()
      .addComponents(
        new ButtonBuilder()
          .setCustomId('can-buy')
          .setLabel('الغاء العمليه')
          .setStyle(ButtonStyle.Danger)
      );
    const embed = new EmbedBuilder()
      .setColor('#000100')
      .setDescription(
        `**اختر نوع الشي الذي تريد شراها**`);
    await interaction.reply({
      embeds: [embed],
      components: [row, rd],
    });
    }
  });