const client = require("../../index.js");
const { EmbedBuilder, ActionRowBuilder , ButtonBuilder , ButtonStyle, TextInputStyle,TextInputBuilder,ModalBuilder } = require("discord.js");
const counters = require('../../Datebase/model/counters/mediator_counter.js');
client.on('interactionCreate', async interaction => {
  if (!interaction.isStringSelectMenu()) return;
  if (interaction.customId === 'mediator') {
    const selectedValue = interaction.values[0];
    if (selectedValue === 'mediator_1') {
      const counter = await counters.updateOne(
        { guildId: interaction.guild.id },
        { $inc: { counter: 1 } },
        { upsert: true }
      );
      const findCount = await counters.findOne({ guildId: interaction.guild.id });
      const ctr = findCount.counter
      const mediator = await interaction.guild.channels.create({
        name: `mediator-${ctr}`,
        type: 0,
        parent: '1224721523944980690',
        permissionOverwrites: [
          {
            id: interaction.guild.id,
            deny: ['ViewChannel'],
          },
          {
            id: interaction.user.id,
            allow: ['ViewChannel'],
          },
         {
            id: "1224829322926227640",
            allow: ['ViewChannel'],
          },
        ],
      });
      await interaction.reply({
        content: `تم إنشاء تذكرتك في ${mediator}`,
        ephemeral: true,
      })
      const row = new ActionRowBuilder()
        .addComponents(
          new ButtonBuilder()
            .setCustomId('Sample')
            .setLabel('النموذج')
            .setStyle(ButtonStyle.Secondary),
          new ButtonBuilder()
            .setCustomId('delete_ticket')
            .setLabel('حذف التذكره')
            .setStyle(ButtonStyle.Danger)
        ); 
const embed = new EmbedBuilder()
.setTitle("**__Mediator Ticket__**")
.setDescription(
  `**- مرحبا عزيزي العضو , انت هنا في تذكرة طلب وسيط لضمانك من عدم النصب وضمان حقك
- يرجى الضغط على الزر بالاسفل (النموذج) وقم بتعبئة البيانات المطلوبة منك لكي يتم بدء عملية التوسط واستلام التذكرة من الوسطاء
- يجب عليك ملأ النموذج بشكل كامل وصحيح وعلى حسب الاتفاق بينك وبين الطرف الآخر وبعناية**`)
.setColor("#2f3136")
.setImage("https://media.discordapp.net/attachments/1223254111139533051/1225103755666522152/20240325_205500.png?ex=661fe9c8&is=660d74c8&hm=d8de04deb85e3d2ed3cbb0e78bf28ca2aa0383f160147027d6f63222016fd523&")
.setTimestamp()
      .setAuthor({
        name: interaction.guild.name,
        iconURL: interaction.guild.iconURL()})
        .setFooter({
        text: interaction.guild.name,
          iconURL: interaction.guild.iconURL()
        })

        .setThumbnail(interaction.guild.iconURL());
      await mediator.send({
        content: `${interaction.user}||<@&1224829322926227640>`,
        components: [row],
        embeds: [embed],
      });

    } else if (selectedValue === 'mediator_2') {
      const counter = await counters.updateOne(
        { guildId: interaction.guild.id },
        { $inc: { counter: 1 } },
        { upsert: true }
      );
      const findCount = await counters.findOne({ guildId: interaction.guild.id });
      const ctr = findCount.counter
      const mediator = await interaction.guild.channels.create({
        name: `mediator-${ctr}`,
        type: 0,
        parent: '1225106019051372554',
        permissionOverwrites: [
          {
            id: interaction.guild.id,
            deny: ['ViewChannel'],
          },
          {
            id: interaction.user.id,
            allow: ['ViewChannel'],
          },
         {
            id: "1224829322926227640",
            allow: ['ViewChannel'],
          },
        ],
      });
      await interaction.reply({
        content: `تم إنشاء تذكرتك في ${mediator}`,
        ephemeral: true,
      })
    const row = new ActionRowBuilder()
        .addComponents(
          new ButtonBuilder()
            .setCustomId('Sample2')
            .setLabel('النموذج')
            .setStyle(ButtonStyle.Secondary),
          new ButtonBuilder()
            .setCustomId('delete_ticket')
            .setLabel('حذف التذكره')
            .setStyle(ButtonStyle.Danger)
        ); 
const embed = new EmbedBuilder()
.setTitle("**__Mediator Ticket__**")
.setDescription(
  `**- مرحبا عزيزي العضو , انت هنا في تذكرة طلب وسيط لضمانك من عدم النصب وضمان حقك
- يرجى الضغط على الزر بالاسفل (النموذج) وقم بتعبئة البيانات المطلوبة منك لكي يتم بدء عملية التوسط واستلام التذكرة من الوسطاء
- يجب عليك ملأ النموذج بشكل كامل وصحيح وعلى حسب الاتفاق بينك وبين الطرف الآخر وبعناية**`)
.setColor("#2f3136")
.setImage("https://media.discordapp.net/attachments/1223254111139533051/1225103755666522152/20240325_205500.png?ex=661fe9c8&is=660d74c8&hm=d8de04deb85e3d2ed3cbb0e78bf28ca2aa0383f160147027d6f63222016fd523&")
.setTimestamp()
      .setAuthor({
        name: interaction.guild.name,
        iconURL: interaction.guild.iconURL()})
        .setFooter({
        text: interaction.guild.name,
          iconURL: interaction.guild.iconURL()
        })

        .setThumbnail(interaction.guild.iconURL());
      await mediator.send({
        content: `${interaction.user}||<@&1224829322926227640>`,
        components: [row],
        embeds: [embed],
      });
    
    } else if (selectedValue === 'mediator_3') {
      const counter = await counters.updateOne(
        { guildId: interaction.guild.id },
        { $inc: { counter: 1 } },
        { upsert: true }
      );
      const findCount = await counters.findOne({ guildId: interaction.guild.id });
      const ctr = findCount.counter
      const mediator = await interaction.guild.channels.create({
        name: `mediator-${ctr}`,
        type: 0,
        parent: '1225106019051372554',
        permissionOverwrites: [
          {
            id: interaction.guild.id,
            deny: ['ViewChannel'],
          },
          {
            id: interaction.user.id,
            allow: ['ViewChannel'],
          },
         {
            id: "1224829322926227640",
            allow: ['ViewChannel'],
          },
        ],
      });
      await interaction.reply({
        content: `تم إنشاء تذكرتك في ${mediator}`,
        ephemeral: true,
      })
    const row = new ActionRowBuilder()
        .addComponents(
          new ButtonBuilder()
            .setCustomId('Sample3')
            .setLabel('النموذج')
            .setStyle(ButtonStyle.Secondary),
          new ButtonBuilder()
            .setCustomId('delete_ticket')
            .setLabel('حذف التذكره')
            .setStyle(ButtonStyle.Danger)
        ); 
const embed = new EmbedBuilder()
.setTitle("**__Mediator Ticket__**")
.setDescription(
  `**- مرحبا عزيزي العضو , انت هنا في تذكرة طلب وسيط لضمانك من عدم النصب وضمان حقك
- يرجى الضغط على الزر بالاسفل (النموذج) وقم بتعبئة البيانات المطلوبة منك لكي يتم بدء عملية التوسط واستلام التذكرة من الوسطاء
- يجب عليك ملأ النموذج بشكل كامل وصحيح وعلى حسب الاتفاق بينك وبين الطرف الآخر وبعناية**`)
.setColor("#2f3136")
.setImage("https://media.discordapp.net/attachments/1223254111139533051/1225103755666522152/20240325_205500.png?ex=661fe9c8&is=660d74c8&hm=d8de04deb85e3d2ed3cbb0e78bf28ca2aa0383f160147027d6f63222016fd523&")
.setTimestamp()
      .setAuthor({
        name: interaction.guild.name,
        iconURL: interaction.guild.iconURL()})
        .setFooter({
        text: interaction.guild.name,
          iconURL: interaction.guild.iconURL()
        })

        .setThumbnail(interaction.guild.iconURL());
      await mediator.send({
        content: `${interaction.user}||<@&1224829322926227640>`,
        components: [row],
        embeds: [embed],
      });
    } else if (selectedValue === 'mediator_4') {
      const counter = await counters.updateOne(
        { guildId: interaction.guild.id },
        { $inc: { counter: 1 } },
        { upsert: true }
      );
      const findCount = await counters.findOne({ guildId: interaction.guild.id });
      const ctr = findCount.counter
      const mediator = await interaction.guild.channels.create({
        name: `mediator-${ctr}`,
        type: 0,
        parent: '1225106019051372554',
        permissionOverwrites: [
          {
            id: interaction.guild.id,
            deny: ['ViewChannel'],
          },
          {
            id: interaction.user.id,
            allow: ['ViewChannel'],
          },
         {
            id: "1224829322926227640",
            allow: ['ViewChannel'],
          },
        ],
      });
      await interaction.reply({
        content: `تم إنشاء تذكرتك في ${mediator}`,
        ephemeral: true,
      })
      const row = new ActionRowBuilder()
        .addComponents(
          new ButtonBuilder()
            .setCustomId('Sample4')
            .setLabel('النموذج')
            .setStyle(ButtonStyle.Secondary),
          new ButtonBuilder()
            .setCustomId('delete_ticket')
            .setLabel('حذف التذكره')
            .setStyle(ButtonStyle.Danger)
        ); 
const embed = new EmbedBuilder()
.setTitle("**__Mediator Ticket__**")
.setDescription(
  `**- مرحبا عزيزي العضو , انت هنا في تذكرة طلب وسيط لضمانك من عدم النصب وضمان حقك
- يرجى الضغط على الزر بالاسفل (النموذج) وقم بتعبئة البيانات المطلوبة منك لكي يتم بدء عملية التوسط واستلام التذكرة من الوسطاء
- يجب عليك ملأ النموذج بشكل كامل وصحيح وعلى حسب الاتفاق بينك وبين الطرف الآخر وبعناية**`)
.setColor("#2f3136")
.setImage("https://media.discordapp.net/attachments/1223254111139533051/1225103755666522152/20240325_205500.png?ex=661fe9c8&is=660d74c8&hm=d8de04deb85e3d2ed3cbb0e78bf28ca2aa0383f160147027d6f63222016fd523&")
.setTimestamp()
      .setAuthor({
        name: interaction.guild.name,
        iconURL: interaction.guild.iconURL()})
        .setFooter({
        text: interaction.guild.name,
          iconURL: interaction.guild.iconURL()
        })

        .setThumbnail(interaction.guild.iconURL());
      await mediator.send({
        content: `${interaction.user}||<@&1224829322926227640>`,
        components: [row],
        embeds: [embed],
      });
    } else if (selectedValue === 'mediator_5') {
      const counter = await counters.updateOne(
        { guildId: interaction.guild.id },
        { $inc: { counter: 1 } },
        { upsert: true }
      );
      const findCount = await counters.findOne({ guildId: interaction.guild.id });
      const ctr = findCount.counter
      const mediator = await interaction.guild.channels.create({
        name: `mediator-${ctr}`,
        type: 0,
        parent: '1225106019051372554',
        permissionOverwrites: [
          {
            id: interaction.guild.id,
            deny: ['ViewChannel'],
          },
          {
            id: interaction.user.id,
            allow: ['ViewChannel'],
          },
         {
            id: "1224829322926227640",
            allow: ['ViewChannel'],
          },
        ],
      });
      await interaction.reply({
        content: `تم إنشاء تذكرتك في ${mediator}`,
        ephemeral: true,
      })
      const row = new ActionRowBuilder()
        .addComponents(
          new ButtonBuilder()
            .setCustomId('Sample5')
            .setLabel('النموذج')
            .setStyle(ButtonStyle.Secondary),
          new ButtonBuilder()
            .setCustomId('delete_ticket')
            .setLabel('حذف التذكره')
            .setStyle(ButtonStyle.Danger)
        ); 
const embed = new EmbedBuilder()
.setTitle("**__Mediator Ticket__**")
.setDescription(
  `**- مرحبا عزيزي العضو , انت هنا في تذكرة طلب وسيط لضمانك من عدم النصب وضمان حقك
- يرجى الضغط على الزر بالاسفل (النموذج) وقم بتعبئة البيانات المطلوبة منك لكي يتم بدء عملية التوسط واستلام التذكرة من الوسطاء
- يجب عليك ملأ النموذج بشكل كامل وصحيح وعلى حسب الاتفاق بينك وبين الطرف الآخر وبعناية**`)
.setColor("#2f3136")
.setImage("https://media.discordapp.net/attachments/1223254111139533051/1225103755666522152/20240325_205500.png?ex=661fe9c8&is=660d74c8&hm=d8de04deb85e3d2ed3cbb0e78bf28ca2aa0383f160147027d6f63222016fd523&")
.setTimestamp()
      .setAuthor({
        name: interaction.guild.name,
        iconURL: interaction.guild.iconURL()})
        .setFooter({
        text: interaction.guild.name,
          iconURL: interaction.guild.iconURL()
        })

        .setThumbnail(interaction.guild.iconURL());
      await mediator.send({
        content: `${interaction.user}||<@&1224829322926227640>`,
        components: [row],
        embeds: [embed],
      });
    }
  }
});
