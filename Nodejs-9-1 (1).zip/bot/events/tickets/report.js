const client = require("../../index.js");
const { EmbedBuilder, ActionRowBuilder , ButtonBuilder , ButtonStyle, TextInputStyle,TextInputBuilder,ModalBuilder } = require("discord.js");
const counters = require('../../Datebase/model/counters/report_counter.js');
client.on('interactionCreate', async interaction => {
  if (!interaction.isStringSelectMenu()) return;
  if (interaction.customId === 'ticket') {
    const selectedValue = interaction.values[0];
    if (selectedValue === 'report') {

    const counter = await counters.updateOne(
      { guildId: interaction.guild.id },
      { $inc: { counter: 1 } },
      { upsert: true }
    );

    const findCount = await counters.findOne({ guildId: interaction.guild.id });

      const ctr = findCount.counter
            const report = await interaction.guild.channels.create({
        name: `report-${ctr}`,
        type: 0,
        parent: '1224721523944980690',
        permissionOverwrites: [
          {
            id: interaction.guild.id,
            deny: ['ViewChannel'],
          },
          {
            id: interaction.user.id,
            allow: ['ViewChannel'],
          },
           {
            id: "1224829322926227640",
            allow: ['ViewChannel'],
          },
        ],
      });

        await interaction.reply({
            content: `تم إنشاء تذكرتك في ${report}`,
            ephemeral: true,
          });
        const row = new ActionRowBuilder()
        .addComponents(
          new ButtonBuilder()
            .setCustomId('Submit_report')
            .setLabel('تقديم بلاغ')
.setStyle(ButtonStyle.Secondary),
          new ButtonBuilder()
            .setCustomId('get_report')
            .setLabel('رفع بلاغ')
          .setStyle(ButtonStyle.Secondary),
          new ButtonBuilder()
          .setCustomId('report_claim')
            .setLabel('استلام التذكره')
          .setStyle(ButtonStyle.Secondary),
          new ButtonBuilder()
            .setCustomId('report_help')
            .setLabel('مساعده القضاه')
          .setStyle(ButtonStyle.Secondary),
          new ButtonBuilder()
          .setCustomId('report_delete_ticket')
            .setLabel('حذف التذكره')
          .setStyle(ButtonStyle.Secondary)
        );
      const embed = new EmbedBuilder()
        .setColor('#000100')
        .setDescription(`**- اهلا وسهلا في تكت الدعم الفني الجديدة
        
- يمكنك شراء شي معين اذا كنت عضو من خلال الازرار بالاسفل**`)
        .setImage('https://media.discordapp.net/attachments/1221073597901049927/1221073800704163860/image_7.png?ex=66114098&is=65fecb98&hm=5879d9f909b56ff07214c277440c1d1e7e9347b50b79a79818f7216beabf118a&')
        .setAuthor({
        name: interaction.guild.name,
        iconURL: interaction.guild.iconURL()})
        .setFooter({
        text: interaction.guild.name,
          iconURL: interaction.guild.iconURL()
        })

        .setThumbnail(interaction.guild.iconURL())

    .setTimestamp();
      await report.send({
        components: [row],
        embeds: [embed],
      });

      }
    }
});