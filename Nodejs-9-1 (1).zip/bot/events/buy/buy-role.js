const client = require("../../index.js");
const config = require("../../config.json")
const { EmbedBuilder, ApplicationCommandOptionType , Events , ActionRowBuilder , ButtonBuilder ,MessageAttachment, ButtonStyle , Message, TextInputStyle,TextInputBuilder,ModalBuilder, StringSelectMenuBuilder, StringSelectMenuOptionBuilder, PermissionsBitField } = require("discord.js");

const users = require('../../Datebase/model/buy.js');

client.on('interactionCreate', async interaction => {
 if (!interaction.isStringSelectMenu()) return;
 if (interaction.customId === 'buy') {
 const selectedValue = interaction.values[0];
 if (selectedValue === 'role') {
 const role = new StringSelectMenuBuilder()
 .setCustomId('role')
 .setPlaceholder('اختر رتبه')
 .addOptions(
 new StringSelectMenuOptionBuilder()
 .setLabel('Angel S')
.setDescription('سعرها : 100k')
 .setValue('Angel S'),
 new StringSelectMenuOptionBuilder()
 .setLabel('Great S')
 .setDescription('سعرها : 80k')
 .setValue('Great S'),
 new StringSelectMenuOptionBuilder()
 .setLabel('Perfect S')
 .setDescription('سعرها : 60k')
 .setValue('Perfect S'),
 new StringSelectMenuOptionBuilder()
 .setLabel('Excellent S')
 .setDescription('سعرها : 40k')
 .setValue('Excellent S'),
 new StringSelectMenuOptionBuilder()
 .setLabel('Good S')
 .setDescription('سعرها : 20k')
 .setValue('Good S'),
 new StringSelectMenuOptionBuilder()
 .setLabel('Designer S')
 .setDescription('سعرها : 15k')
 .setValue('Designer S'),
 new StringSelectMenuOptionBuilder()
 .setLabel('Developer S')
 .setDescription('سعرها : 15k')
 .setValue('Developer S'),
 );
 const row = new ActionRowBuilder()
 .addComponents(role);
   const rd = new ActionRowBuilder()
      .addComponents(
        new ButtonBuilder()
          .setCustomId('can-buy')
          .setLabel('الغاء العمليه')
          .setStyle(ButtonStyle.Danger)
      );
 const embed = new EmbedBuilder()
 .setColor('#000100')
 .setDescription(
 `**اختر رتبه الذي تريد شراها**`);
 await interaction.update({
 embeds: [embed],
 components: [row, rd],
  });
      } 
  } else if (interaction.customId === 'role') {
 const selectedValue = interaction.values[0];
if (selectedValue === 'Angel S') {
  let price = config.priceAngelS;
  const result = price; 
  let finalprice = Math.floor(price *(20) / (19) + (1))
  let roleid = config.roleidAngelS;

  let owner = config.owner;
  if(interaction.member.roles.cache.some((role) => role.id === roleid)) return interaction.reply({content:`**انت بالفعل لديك هذه الرتبة  .. **`,ephemeral:true})

  const embed = new EmbedBuilder()
  .setColor('#000100')
  .setDescription(
  `**قم بتحويل ${finalprice} لـ <@${owner}>**\n\`\`\`#credit <@${owner}> ${finalprice}\`\`\``)
  .setTimestamp();
  await interaction.update({
  embeds: [embed],
  components: [],
  })
  await interaction.channel.send({
  content: `#credit ${owner} ${finalprice}`
  })
  const filter = ({ content, author: { id } }) => {
        return (
            content.startsWith(`**:moneybag: | ${interaction.user.username}, has transferred `) &&
            content.includes(`${owner}`) &&
            id === "282859044593598464" &&
            (Number(content.slice(content.lastIndexOf("`") - String(finalprice).length, content.lastIndexOf("`"))) >= result)
        );
    };

    const collector = interaction.channel.createMessageCollector({ 
      filter,               
      max: 1,
      time: 60000,
    });
let iscollected = false;
collector.on('collect', async (collected) => {
  iscollected = true;
  const embed = new EmbedBuilder()
  .setColor('#000100')
  .setDescription(`**تم اعطائك الرتبه بنجاح**`)
  .setTimestamp();
  await interaction.editReply({
  embeds: [embed],
  components: [],
  })
  await interaction.member.roles.add(roleid);
  
const user = await users.deleteOne({ userId: interaction.user.id });
  
const log = client.channels.cache.get(config.log)
const logembed = new EmbedBuilder()
.setColor('#000100')
.setTitle("شراء رتبة")
  
  .addFields(
        {
          name: "تم شراء بواسطة",
          value: `<@${interaction.member.id}>`,
          inline: true
        },
        {
          name: "تم شراء رتبة",
          value: `<@&${roleid}>`,
          inline: true
        },
        {
          name: "المبلغ",
          value: `${finalprice}`,
          inline: true
        }
  ) 
.setColor(`#000100`)
.setThumbnail(interaction.guild.iconURL({dynamic:true}))
    .setTimestamp();
await log.send({embeds:[logembed]})
 })
collector.on('end', async (collected) => {
  if (!iscollected) {
    const embed = new EmbedBuilder()
    .setColor('#000100')
    .setDescription(`**انتهى وقت العمليه**`)
    .setTimestamp();
    await interaction.editReply({
    embeds: [embed],
    components: [],
    })
    const user = await users.deleteOne({ userId: interaction.user.id });
  }
});

   } else if (selectedValue === 'Great S') {
  let price = config.priceGreatS;
  const result = price; 
  let finalprice = Math.floor(price *(20) / (19) + (1))
  let roleid = config.roleidGreatS;

  let owner = config.owner;
  if(interaction.member.roles.cache.some((role) => role.id === roleid)) return interaction.reply({content:`**انت بالفعل لديك هذه الرتبة  .. **`,ephemeral:true})

  const embed = new EmbedBuilder()
  .setColor('#000100')
  .setDescription(
  `**قم بتحويل ${finalprice} لـ <@${owner}>**\n\`\`\`#credit <@${owner}> ${finalprice}\`\`\``)
  .setTimestamp();
  await interaction.update({
  embeds: [embed],
  components: [],
  })
  await interaction.channel.send({
  content: `#credit ${owner} ${finalprice}`
  })
  const filter = ({ content, author: { id } }) => {
        return (
            content.startsWith(`**:moneybag: | ${interaction.user.username}, has transferred `) &&
            content.includes(`${owner}`) &&
            id === "282859044593598464" &&
            (Number(content.slice(content.lastIndexOf("`") - String(finalprice).length, content.lastIndexOf("`"))) >= result)
        );
  };
  const collector = interaction.channel.createMessageCollector({
    filter,               
    max: 1,
    time: 60000,
  })
let iscollected = false;
collector.on('collect', async (collected) => {
  iscollected = true;
  const embed = new EmbedBuilder()
  .setColor('#000100')
  .setDescription(`**تم اعطائك الرتبه بنجاح**`)
  .setTimestamp();
  await interaction.editReply({
  embeds: [embed],
  components: [],
  })
  await interaction.member.roles.add(roleid);
  const user = await users.deleteOne({ userId: interaction.user.id });


  
const log = client.channels.cache.get(config.log)
const logembed = new EmbedBuilder()
.setColor('#000100')
.setTitle("شراء رتبة")
.addFields(
        {
          name: "تم شراء بواسطة",
          value: `<@${interaction.member.id}>`,
          inline: true
        },
        {
          name: "تم شراء رتبة",
          value: `<@&${roleid}>`,
          inline: true
        },
        {
          name: "المبلغ",
          value: `${finalprice}`,
          inline: true
        }
  ) 
.setThumbnail(interaction.guild.iconURL({dynamic:true}))
    .setTimestamp();
await log.send({embeds:[logembed]})
})
collector.on('end', async (collected) => {
  if (!iscollected) {
    const embed = new EmbedBuilder()
    .setColor('#000100')
    .setDescription(`**انتهى وقت العمليه**`)
    .setTimestamp();
    await interaction.editReply({
    embeds: [embed],
    components: [],
    })
    const user = await users.deleteOne({ userId: interaction.user.id });
  }
});
   } else if (selectedValue === 'Perfect S') {
    let price = config.pricePerfectS;
  const result = price; 
  let finalprice = Math.floor(price *(20) / (19) + (1))
  let roleid = config.roleidPerfectS;

  let owner = config.owner;
  if(interaction.member.roles.cache.some((role) => role.id === roleid)) return interaction.reply({content:`**انت بالفعل لديك هذه الرتبة  .. **`,ephemeral:true})

  const embed = new EmbedBuilder()
  .setColor('#000100')
  .setDescription(
  `**قم بتحويل ${finalprice} لـ <@${owner}>**\n\`\`\`#credit <@${owner}> ${finalprice}\`\`\``)
  .setTimestamp();
  await interaction.update({
  embeds: [embed],
  components: [],
  })
  await interaction.channel.send({
  content: `#credit ${owner} ${finalprice}`
  })
  const filter = ({ content, author: { id } }) => {
        return (
            content.startsWith(`**:moneybag: | ${interaction.user.username}, has transferred `) &&
            content.includes(`${owner}`) &&
            id === "282859044593598464" &&
            (Number(content.slice(content.lastIndexOf("`") - String(finalprice).length, content.lastIndexOf("`"))) >= result)
        );
  };
  const collector = interaction.channel.createMessageCollector({
    filter,               
    max: 1,
    time: 60000,
  })
let iscollected = false;
collector.on('collect', async (collected) => {
  iscollected = true;
  const embed = new EmbedBuilder()
  .setColor('#000100')
  .setDescription(`**تم اعطائك الرتبه بنجاح**`)
  .setTimestamp();
  await interaction.editReply({
  embeds: [embed],
  components: [],
  })
  await interaction.member.roles.add(roleid);

  const user = await users.deleteOne({ userId: interaction.user.id });


const log = client.channels.cache.get(config.log)
const logembed = new EmbedBuilder()
.setColor('#000100')
.setTitle("شراء رتبة")
.addFields(
        {
          name: "تم شراء بواسطة",
          value: `<@${interaction.member.id}>`,
          inline: true
        },
        {
          name: "تم شراء رتبة",
          value: `<@&${roleid}>`,
          inline: true
        },
        {
          name: "المبلغ",
          value: `${finalprice}`,
          inline: true
        }
  ) 
.setThumbnail(interaction.guild.iconURL({dynamic:true}))
    .setTimestamp();
await log.send({embeds:[logembed]})
})
collector.on('end', async (collected) => {
  if (!iscollected) {
    const embed = new EmbedBuilder()
    .setColor('#000100')
    .setDescription(`**انتهى وقت العمليه**`)
    .setTimestamp();
    await interaction.editReply({
    embeds: [embed],
    components: [],
    })
    const user = await users.deleteOne({ userId: interaction.user.id });
  }
});

   } else if (selectedValue === 'Excellent S') {
  let price = config.priceExcellentS;
  const result = price; 
  let finalprice = Math.floor(price *(20) / (19) + (1))
  let roleid = config.roleidExcellentS;

  let owner = config.owner;
  if(interaction.member.roles.cache.some((role) => role.id === roleid)) return interaction.reply({content:`**انت بالفعل لديك هذه الرتبة  .. **`,ephemeral:true})

  const embed = new EmbedBuilder()
  .setColor('#000100')
  .setDescription(
  `**قم بتحويل ${finalprice} لـ <@${owner}>**\n\`\`\`#credit <@${owner}> ${finalprice}\`\`\``)
  .setTimestamp();
  await interaction.update({
  embeds: [embed],
  components: [],
  })
  await interaction.channel.send({
  content: `#credit ${owner} ${finalprice}`
  })
  const filter = ({ content, author: { id } }) => {
        return (
            content.startsWith(`**:moneybag: | ${interaction.user.username}, has transferred `) &&
            content.includes(`${owner}`) &&
            id === "282859044593598464" &&
            (Number(content.slice(content.lastIndexOf("`") - String(finalprice).length, content.lastIndexOf("`"))) >= result)
        );
  };
  const collector = interaction.channel.createMessageCollector({
    filter,               
    max: 1,
    time: 60000,
  })
let iscollected = false;
collector.on('collect', async (collected) => {
  iscollected = true;
  const embed = new EmbedBuilder()
  .setColor('#000100')
  .setDescription(`**تم اعطائك الرتبه بنجاح**`)
  .setTimestamp();
  await interaction.editReply({
  embeds: [embed],
  components: [],
  })
  await interaction.member.roles.add(roleid);

const user = await users.deleteOne({ userId: interaction.user.id });
  
const log = client.channels.cache.get(config.log)
const logembed = new EmbedBuilder()
.setColor('#000100')
.setTitle("شراء رتبة")
.addFields(
        {
          name: "تم شراء بواسطة",
          value: `<@${interaction.member.id}>`,
          inline: true
        },
        {
          name: "تم شراء رتبة",
          value: `<@&${roleid}>`,
          inline: true
        },
        {
          name: "المبلغ",
          value: `${finalprice}`,
          inline: true
        }
  ) 
.setThumbnail(interaction.guild.iconURL({dynamic:true}))
    .setTimestamp();
await log.send({embeds:[logembed]})
})
collector.on('end', async (collected) => {
  if (!iscollected) {
    const embed = new EmbedBuilder()
    .setColor('#000100')
    .setDescription(`**انتهى وقت العمليه**`)
    .setTimestamp();
    await interaction.editReply({
    embeds: [embed],
    components: [],
    })
    const user = await users.deleteOne({ userId: interaction.user.id });
  }
});

   } else if (selectedValue === 'Good S') {
    let price = config.priceGoodS;
  
  const result = price; 
  let finalprice = Math.floor(price *(20) / (19) + (1))
  let roleid = config.roleidGoodS;

  let owner = config.owner;
  if(interaction.member.roles.cache.some((role) => role.id === roleid)) return interaction.reply({content:`**انت بالفعل لديك هذه الرتبة  .. **`,ephemeral:true})

  const embed = new EmbedBuilder()
  .setColor('#000100')
  .setDescription(
  `**قم بتحويل ${finalprice} لـ <@${owner}>**\n\`\`\`#credit <@${owner}> ${finalprice}\`\`\``)
  .setTimestamp();
  await interaction.update({
  embeds: [embed],
  components: [],
  })
  await interaction.channel.send({
  content: `#credit ${owner} ${finalprice}`
  })
  const filter = ({ content, author: { id } }) => {
        return (
            content.startsWith(`**:moneybag: | ${interaction.user.username}, has transferred `) &&
            content.includes(`${owner}`) &&
            id === "282859044593598464" &&
            (Number(content.slice(content.lastIndexOf("`") - String(finalprice).length, content.lastIndexOf("`"))) >= result)
        );
  };
  const collector = interaction.channel.createMessageCollector({
    filter,               
    max: 1,
    time: 60000,
  })
let iscollected = false;
collector.on('collect', async (collected) => {
  iscollected = true;
  const embed = new EmbedBuilder()
  .setColor('#000100')
  .setDescription(`**تم اعطائك الرتبه بنجاح**`)
  .setTimestamp();
  await interaction.editReply({
  embeds: [embed],
  components: [],
  })
  await interaction.member.roles.add(roleid);

const user = await users.deleteOne({ userId: interaction.user.id });
  
const log = client.channels.cache.get(config.log)
const logembed = new EmbedBuilder()
.setColor('#000100')
.setTitle("شراء رتبة")
.addFields(
        {
          name: "تم شراء بواسطة",
          value: `<@${interaction.member.id}>`,
          inline: true
        },
        {
          name: "تم شراء رتبة",
          value: `<@&${roleid}>`,
          inline: true
        },
        {
          name: "المبلغ",
          value: `${finalprice}`,
          inline: true
        }
  ) 
.setThumbnail(interaction.guild.iconURL({dynamic:true}))
    .setTimestamp();
await log.send({embeds:[logembed]})
})
collector.on('end', async (collected) => {
  if (!iscollected) {
    const embed = new EmbedBuilder()
    .setColor('#000100')
    .setDescription(`**انتهى وقت العمليه**`)
    .setTimestamp();
    await interaction.editReply({
    embeds: [embed],
    components: [],
    })
    const user = await users.deleteOne({ userId: interaction.user.id });
  }
});

   } else if (selectedValue === 'Designer S') {
      let price = config.priceDesignerS;
  const result = price; 
  let finalprice = Math.floor(price *(20) / (19) + (1))
  let roleid = config.roleidDesignerS;

  let owner = config.owner;
  if(interaction.member.roles.cache.some((role) => role.id === roleid)) return interaction.reply({content:`**انت بالفعل لديك هذه الرتبة  .. **`,ephemeral:true})

  const embed = new EmbedBuilder()
  .setColor('#000100')
  .setDescription(
  `**قم بتحويل ${finalprice} لـ <@${owner}>**\n\`\`\`#credit <@${owner}> ${finalprice}\`\`\``)
  .setTimestamp();
  await interaction.update({
  embeds: [embed],
  components: [],
  })
  await interaction.channel.send({
  content: `#credit ${owner} ${finalprice}`
  })
  const filter = ({ content, author: { id } }) => {
        return (
            content.startsWith(`**:moneybag: | ${interaction.user.username}, has transferred `) &&
            content.includes(`${owner}`) &&
            id === "282859044593598464" &&
            (Number(content.slice(content.lastIndexOf("`") - String(finalprice).length, content.lastIndexOf("`"))) >= result)
        );
  };
  const collector = interaction.channel.createMessageCollector({
    filter,               
    max: 1,
    time: 60000,
  })
let iscollected = false;
collector.on('collect', async (collected) => {
  iscollected = true;
  const embed = new EmbedBuilder()
  .setColor('#000100')
  .setDescription(`**تم اعطائك الرتبه بنجاح**`)
  .setTimestamp();
  await interaction.editReply({
  embeds: [embed],
  components: [],
  })
  await interaction.member.roles.add(roleid);

const user = await users.deleteOne({ userId: interaction.user.id });
  
const log = client.channels.cache.get(config.log)
const logembed = new EmbedBuilder()
.setColor('#000100')
.setTitle("شراء رتبة")
.addFields(
        {
          name: "تم شراء بواسطة",
          value: `<@${interaction.member.id}>`,
          inline: true
        },
        {
          name: "تم شراء رتبة",
          value: `<@&${roleid}>`,
          inline: true
        },
        {
          name: "المبلغ",
          value: `${finalprice}`,
          inline: true
        }
  ) 
.setThumbnail(interaction.guild.iconURL({dynamic:true}))
    .setTimestamp();
await log.send({embeds:[logembed]})
})
collector.on('end', async (collected) => {
  if (!iscollected) {
    const embed = new EmbedBuilder()
    .setColor('#000100')
    .setDescription(`**انتهى وقت العمليه**`)
    .setTimestamp();
    await interaction.editReply({
    embeds: [embed],
    components: [],
    })
    const user = await users.deleteOne({ userId: interaction.user.id });
  }
});

   } else if (selectedValue === 'Developer S') {
  let price = config.priceDeveloperS;
  const result = price; 
  let finalprice = Math.floor(price *(20) / (19) + (1))
  let roleid = config.roleidDeveloperS;

  let owner = config.owner;
  if(interaction.member.roles.cache.some((role) => role.id === roleid)) return interaction.reply({content:`**انت بالفعل لديك هذه الرتبة  .. **`,ephemeral:true})

  const embed = new EmbedBuilder()
  .setColor('#000100')
  .setDescription(
  `**قم بتحويل ${finalprice} لـ <@${owner}>**\n\`\`\`#credit <@${owner}> ${finalprice}\`\`\``)
  .setTimestamp();
  await interaction.update({
  embeds: [embed],
  components: [],
  })
  await interaction.channel.send({
  content: `#credit ${owner} ${finalprice}`
  })
  const filter = ({ content, author: { id } }) => {
        return (
            content.startsWith(`**:moneybag: | ${interaction.user.username}, has transferred `) &&
            content.includes(`${owner}`) &&
            id === "282859044593598464" &&
            (Number(content.slice(content.lastIndexOf("`") - String(finalprice).length, content.lastIndexOf("`"))) >= result)
        );
  };
  const collector = interaction.channel.createMessageCollector({
    filter,               
    max: 1,
    time: 60000,
  })
let iscollected = false;
collector.on('collect', async (collected) => {
  iscollected = true;
  const embed = new EmbedBuilder()
  .setColor('#000100')
  .setDescription(`**تم اعطائك الرتبه بنجاح**`)
  .setTimestamp();
  await interaction.editReply({
  embeds: [embed],
  components: [],
  })
  await interaction.member.roles.add(roleid);

const user = await users.deleteOne({ userId: interaction.user.id });
  
const log = client.channels.cache.get(config.log)
const logembed = new EmbedBuilder()
.setColor('#000100')
.setTitle("شراء رتبة")
.addFields(
        {
          name: "تم شراء بواسطة",
          value: `<@${interaction.member.id}>`,
          inline: true
        },
        {
          name: "تم شراء رتبة",
          value: `<@&${roleid}>`,
          inline: true
        },
        {
          name: "المبلغ",
          value: `${finalprice}`,
          inline: true
        }
  ) 
.setThumbnail(interaction.guild.iconURL({dynamic:true}))
    .setTimestamp();
await log.send({embeds:[logembed]})
})
collector.on('end', async (collected) => {
  if (!iscollected) {
    const embed = new EmbedBuilder()
    .setColor('#000100')
    .setDescription(`**انتهى وقت العمليه**`)
    .setTimestamp();
    await interaction.editReply({
    embeds: [embed],
    components: [],
    })
    const user = await users.deleteOne({ userId: interaction.user.id });
  }
});

   }
 }
});