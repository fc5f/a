const client = require("../../index.js");
const config = require("../../config.json")
const { EmbedBuilder, ApplicationCommandOptionType , Events , ActionRowBuilder , ButtonBuilder ,MessageAttachment, ButtonStyle , Message, TextInputStyle,TextInputBuilder,ModalBuilder, StringSelectMenuBuilder, StringSelectMenuOptionBuilder, PermissionsBitField } = require("discord.js");

const users = require('../../Datebase/model/buy.js');






  


client.on('interactionCreate', async interaction => {
 if (!interaction.isStringSelectMenu()) return;
 if (interaction.customId === 'buy') {
 const selectedValue = interaction.values[0];
 if (selectedValue === 'manshort') {
 const mention = new StringSelectMenuBuilder()
 .setCustomId('mention')
 .setPlaceholder('اختر نوع المنشن')
 .addOptions(
 new StringSelectMenuOptionBuilder()
 .setLabel('Here')
 .setDescription('منشن هير')
 .setValue('here'),
 new StringSelectMenuOptionBuilder()
 .setLabel('Everyone')
 .setDescription('منشن ايفري')
 .setValue('everyone')
 );
 const row = new ActionRowBuilder()
 .addComponents(mention);
   const rd = new ActionRowBuilder()
      .addComponents(
        new ButtonBuilder()
          .setCustomId('can-buy')
          .setLabel('الغاء العمليه')
          .setStyle(ButtonStyle.Danger)
      );
 const embed = new EmbedBuilder()
 .setColor('#000100')
 .setDescription(
 `**اختر نوع المنشن الذي تريده**`)
 await interaction.update({
 embeds: [embed],
 components: [row, rd],
 });
    }
  } else if (interaction.customId === 'mention') {
   const selectedValue = interaction.values[0];
   if (selectedValue === 'here') {
     let price = config.price_manshort_here;
     let result = price;
     
     let tax = Math.floor(price * (20 / 19) + 1);
     let owner = config.owner;
     const embed = new EmbedBuilder()
     .setColor('#000100')
     .setTitle('عملية شراء منشور مميز منشن هير')
     .setDescription(`لأكمال عملية شراء المنشور المميز , يرجي نسخ الكود بالاسفل واتمام عملية التحويل

 \`\`\`#credit ${owner} ${tax}\`\`\``)
     
         .setAuthor({
             name: interaction.guild.name,
             iconURL: interaction.guild.iconURL()})
             .setFooter({
             text: interaction.guild.name,
               iconURL: interaction.guild.iconURL()
             })

             .setThumbnail(interaction.guild.iconURL())

         .setTimestamp();
      await interaction.update({
  embeds: [embed],
  components: [],
  })
  await interaction.channel.send({
  content: `#credit ${owner} ${tax}`
  })
  const filter = ({ content, author: { id } }) => {
    return (
        content.startsWith(`**:moneybag: | ${interaction.user.username}, has transferred `) &&
        content.includes(`${owner}`) &&
        id === "282859044593598464" &&
        (Number(content.slice(content.lastIndexOf("`") - String(tax).length, content.lastIndexOf("`"))) >= result)
    );
  };

  const collector = interaction.channel.createMessageCollector({ 
  filter,               
  max: 1,
  time: 60000,
  });
  let iscollected = false;
  collector.on('collect', async (collected) => {
  iscollected = true;
  const embed = new EmbedBuilder()
  .setColor('#000100')
  .setTitle(
  `تمت عملية الشراء بنجاح`)
  .setDescription(
  `**تم شراء المنشور المميز بنجاح**`)
  .setAuthor({
             name: interaction.guild.name,
             iconURL: interaction.guild.iconURL()})
             .setFooter({
             text: interaction.guild.name,
               iconURL: interaction.guild.iconURL()
             })

             .setThumbnail(interaction.guild.iconURL())

         .setTimestamp();
      const row = new ActionRowBuilder()
      .addComponents(
        new ButtonBuilder()
          .setCustomId('here-manshort')
          .setLabel('قم بوضع منشورك هنا')
          .setStyle(ButtonStyle.Success)
      );
      await interaction.editReply({
  embeds: [embed],
  components: [row],
  });
  const user = await users.deleteOne({ userId: interaction.user.id });
    
});
collector.on('end', async (collected) => {
  if (!iscollected) {
  const embed = new EmbedBuilder()
  .setColor('#000100')
  .setTitle(
  `انتهى وقت العمليه`)
  .setDescription(
  `**انتهى وقت العمليه**`)
    .setAuthor({
         name: interaction.guild.name,
         iconURL: interaction.guild.iconURL()})
         .setFooter({
         text: interaction.guild.name,
           iconURL: interaction.guild.iconURL()
         })

         .setThumbnail(interaction.guild.iconURL())

     .setTimestamp();
  await interaction.editReply({
  embeds: [embed],
  components: [],
  });
  const user = await users.deleteOne({ userId: interaction.user.id });
  }
});

   } else if (selectedValue === 'everyone') {
     let price = config.price_manshort_everyone;
     let result = price;
     
     let tax = Math.floor(price * (20 / 19) + 1);
     let owner = config.owner;
     const embed = new EmbedBuilder()
     .setColor('#000100')
     .setTitle('عملية شراء منشور مميز منشن ايفري')
          .setDescription(`لأكمال عملية شراء المنشور المميز , يرجي نسخ الكود بالاسفل واتمام عملية التحويل

 \`\`\`#credit ${owner} ${tax}\`\`\``)
     
         .setAuthor({
             name: interaction.guild.name,
             iconURL: interaction.guild.iconURL()})
             .setFooter({
             text: interaction.guild.name,
               iconURL: interaction.guild.iconURL()
             })

             .setThumbnail(interaction.guild.iconURL())

         .setTimestamp();
      await interaction.update({
  embeds: [embed],
  components: [],
  })
  await interaction.channel.send({
  content: `#credit ${owner} ${tax}`
  })
  const filter = ({ content, author: { id } }) => {
    return (
        content.startsWith(`**:moneybag: | ${interaction.user.username}, has transferred `) &&
        content.includes(`${owner}`) &&
        id === "282859044593598464" &&
        (Number(content.slice(content.lastIndexOf("`") - String(tax).length, content.lastIndexOf("`"))) >= result)
    );
  };
  const collector = interaction.channel.createMessageCollector({ 
  filter,               
  max: 1,
  time: 60000,
  });
  let iscollected = false;
  collector.on('collect', async (collected) => {
  iscollected = true;
  const embed = new EmbedBuilder()
  .setColor('#000100')
  .setTitle(
  `تمت عملية الشراء بنجاح`)
  .setDescription(
  `**تم شراء المنشور المميز بنجاح**`)
  .setAuthor({
             name: interaction.guild.name,
             iconURL: interaction.guild.iconURL()})
             .setFooter({
             text: interaction.guild.name,
               iconURL: interaction.guild.iconURL()
             })

             .setThumbnail(interaction.guild.iconURL())

         .setTimestamp();
      const row = new ActionRowBuilder()
      .addComponents(
        new ButtonBuilder()
          .setCustomId('everyone-manshort')
          .setLabel('قم بوضع منشورك هنا')
          .setStyle(ButtonStyle.Success)
      );
      await interaction.editReply({
  embeds: [embed],
  components: [row],
  });
    const user = await users.deleteOne({ userId: interaction.user.id });
});
collector.on('end', async (collected) => {
  if (!iscollected) {
  const embed = new EmbedBuilder()
  .setColor('#000100')
  .setTitle(
  `انتهى وقت العمليه`)
  .setDescription(
  `**انتهى وقت العمليه**`)
    .setAuthor({
         name: interaction.guild.name,
         iconURL: interaction.guild.iconURL()})
         .setFooter({
         text: interaction.guild.name,
           iconURL: interaction.guild.iconURL()
         })

         .setThumbnail(interaction.guild.iconURL())

     .setTimestamp();
  await interaction.editReply({
  embeds: [embed],
  components: [],
  });
    const user = await users.deleteOne({ userId: interaction.user.id });
  }
});
   }
 }
});
client.on('interactionCreate', async interaction => {
if (!interaction.isButton()) return;
  if (interaction.customId === 'here-manshort') {
    const modal = new ModalBuilder()
    .setCustomId('here-manshort')
    .setTitle('المنشور المميز');
    const heremanshort = new TextInputBuilder()
    .setCustomId('heremanshort')
    .setLabel('اكتب منشورك هنا')
    .setStyle(TextInputStyle.Paragraph);
    const row1 = new ActionRowBuilder().addComponents(heremanshort);
    
    modal.addComponents(row1);
    await interaction.showModal(modal);
  } else if (interaction.customId === 'everyone-manshort') {
    const modal = new ModalBuilder()
    .setCustomId('everyone-manshort')
    .setTitle('المنشور المميز');
    const heremanshort = new TextInputBuilder()
    .setCustomId('everonemanshort')
    .setLabel('اكتب منشورك هنا')
    .setStyle(TextInputStyle.Paragraph);
    const row1 = new ActionRowBuilder().addComponents(heremanshort);
    
    modal.addComponents(row1);
    await interaction.showModal(modal);
  }

});


  
client.on("interactionCreate", async interaction => {
  if (!interaction.isModalSubmit()) return;
  if (interaction.customId === 'here-manshort'){
    const heremanshort = interaction.fields.getTextInputValue('heremanshort');






    const bad = ["👉👌",
"🖕",
 "احا",
 "احه",
 "اير",
 "لعين",
 "واطي",
  "ال",
  "المرا",
  "المره",
  "النيك",
  "عاهر",
  "كلب",
  "احيه",
  "اخو ال",
  "اخو القحبه",
  "افسخك",
  "اقلب وجهك",
  "الخرائ",
  "الزب",
  "السافل",
  "الساقط",
  "العايب",
  "العربان",
  "العرص",
  "العمى",
  "القحبه",
  "الكحبه",
  "الكحبه",
  "الكس",
  "الكلب",
  " ياخ",
  "انذال",
  "انذل",
  "انكح",
  "انيك",
  "انيكك",
  "اهبل",
  "اونطه",
  "اونطه",
  "اونطي",
  "ايري",
  "ايور",
  "بزاز",
  "بعبص",
  "بعص",
  "بغاي",
  "بندوق",
  "بهيمه",
  "تافه",
  "تجليخ",
  "ترهيط",
  "تسد بوزك",
  "تفو",
  "جلخ",
  "جلق",
  "حرامي",
  "حقير",
  "حلبتها",
  "حلبتو",
  "حلمات",
  "حمير",
  "حيوان",
  "خرا",
  "خراء",
  "خراي عل",
  "خراي",
  "خره",
  "خرى",
  "خري",
  "خسيس",
  "خنيث",
  "خوازيق",
  "خول",
  "داشر",
  "داعر",
  "دعاره",
  "دلخ",
  "ديوث",
  "ديود",
  "زامل",
  "زب",
  "زبار",
  "زبر",
  "زبه",
  "زبي",
  "زراط",
  "زق",
  "زناه",
  "زناطير",
  "ساذج",
  "سارموتا",
  "سافل",
  "سرموتا",
  "سفاله",
  "سكسي",
  "سيكس",
  "سيكسي",
  "شرمها",
  "شرموط",
  "شرموطه",
  "شرموطه",
  "شلقه",
  "شلكه",
  "صايع",
  "صياعه",
  "ضرب عشره",
  "طز في",
  "طيز",
  "عاهر",
  "عاهره",
  "عايبه",
  "عبيط",
  "عرص",
  "عكروت",
  "غبي",
  "غتصب",
  "فاجر",
  "فاسق",
  "فجور",
  "فسختها",
  "قحاب",
  "قحب",
  "قحبه",
  "قذر",
  "قضيب",
  "قضيبي",
  "كحبه",
  "كذاب",
  "كس",
  "كسا",
  "كسمك",
  "كسمكم",
  "كسها",
  "كلاب",
  "كلب",
  "كلخر",
  "لحس",
  "لعنه",
  "لقحاب",
  "لوطي",
  "مأجور",
  "مبعوص",
  "متخوزق",
  "متناك",
  "مجنون",
  "مخانيث",
  "مخنث",
  "مدلس",
  "معوهر",
  "مفسوخ",
  "مكسكس",
  "مكوتها",
                  "ممحون",
  "منايك",
  "منيك",
  "منيوك",
  "ناكك",
  "نجس",
  "نذل",
  "نفضك",
  "نفظك",
  "نكت",
  "نياكه",
  "نياكه",
  "وسخ",
  "يتناك",
  "يزغب",
  "يفضح",
  "يفظح",
  "يولاد ال",
  "يلعن",
  "سكس",
  "طيزي",
  "طيزو",
  "شرج",
  "لعق",
  "لحس",
  "مص",
  "تمص",
  "بيضان",
  "ثدي",
  "بز",
  "بزاز",
  "حلمه",
  "مفلقسه",
  "بظر",
  "كس",
  "كسي",
  "فرج",
  "شهوه",
  "شاذ",
  "مبادل",
  "عاهره",
  "جماع",
  "قضيب",
  "زب",
  "لوطي",
  "لواط",
  "سحاق",
  "سحاقيه",
  "اغتصاب",
  "خنثي",
  "احتلام",
  "نيك",
  "متناك",
  "متناكه",
  "شرموطه",
  "عرص",
  "خول",
  "قحبه",
  "لبوه",
  "السكس",
  "الطيز",
  "الطيزي",
  "الطيزو",
  "الشرج",
  "اللعق",
  "اللحس",
  "المص",
  "التمص",
  "البيضان",
  "الثدي",
  "البز",
  "البزاز",
  "الحلمه",
  "المفلقسه",
  "البظر",
  "الكس",
  "الكسي",
  "الفرج",
  "الشهوه",
  "الشاذ",
  "المبادل",
  "العاهره",
  "الجماع",
  "القضيب",
  "الزب",
  "اللوطي",
  "اللواط",
  "السحاق",
  "السحاقيه",
  "الاغتصاب",
  "الخنثي",
  "الخنثي",
  "الاحتلام",
  "النيك",
  "المتناك",
  "المتناكه",
  "الشرموطه",
  "العرص",
  "الخول",
  "القحبه",
  "اللبوه",
  "الفشخه",
  "فشخه",
  "هنيكك",
  "الممحونه",
  "ممحونه",
  "ايري",
  "الاير",
  "بخش",
  "البخش",
  "بخشي",
  "طيزا",
  "عكروت",
  "نايك",
  "انكحك",
  "انتاك",
    "خرايا",
  "ديوث",
  "قواد",
  "يلعن",
  "يلعنك",
  "ملحات",
  "زاكا",
  "صرمك يا خول"
];

    if (bad.some(word => heremanshort.includes(word))) { 
      const embed = new EmbedBuilder()
        .setColor('#000100')
        .setTitle(`عملية الشراء تم الغاءها`)
        .setDescription(`**تم إلغاء عملية الشراء لأن الرسالة تحتوي على كلمات ممنوعة**`);
      await interaction.reply({
        embeds: [embed],
        ephemeral: true,
      });
    } else {


  

          
      


    const channel = interaction.guild.channels.cache.get(config.manshortchannel);
     const embed = new EmbedBuilder()
     .setColor('#000100')
     .setTitle('تم نشر منشورك بنجاح')
     .setDescription("`**تم عمالية الشراء سيتم قفل تكت بعد 3 ثواني .**`")
    
      const row = new ActionRowBuilder()
      .addComponents(
        new ButtonBuilder()
          .setCustomId('1')
        .setLabel('تم شراء بنجاح')
.setStyle(ButtonStyle.Success)
.setDisabled(true)
      ); 
    await interaction.update({
      components: [row],
      embeds: [embed]
    })
  
    
    await channel.send({
      content: `${heremanshort}\nتواصل مع : <@${interaction.user.id}>\n@here`
    });
    await channel.send({
      content: `ليس لنا أدنى علاقه بما يحدث بينكم بالخاص كلها منشورات مدفوعه ، لطلب منشور مثله حياك #⌬〢تكتات`
    })
  await interaction.editReply({
    content: `تم ارسال منشورك بنجاح`,
    ephemeral: true })
  setTimeout(async () => {
interaction.channel.delete() 
}, 3000)
   }
} else if (interaction.customId === 'everyone-manshort') {
    const everonemanshort = interaction.fields.getTextInputValue('everonemanshort');

    const bads = ["👉👌",
"🖕",
 "احا",
 "احه",
 "اير",
 "لعين",
 "واطي",
  "ال",
  "المرا",
  "المره",
  "النيك",
  "عاهر",
  "كلب",
  "احيه",
  "اخو ال",
  "اخو القحبه",
  "افسخك",
  "اقلب وجهك",
  "الخرائ",
  "الزب",
  "السافل",
  "الساقط",
  "العايب",
  "العربان",
  "العرص",
  "العمى",
  "القحبه",
  "الكحبه",
  "الكحبه",
  "الكس",
  "الكلب",
  " ياخ",
  "انذال",
  "انذل",
  "انكح",
  "انيك",
  "انيكك",
  "اهبل",
  "اونطه",
  "اونطه",
  "اونطي",
  "ايري",
  "ايور",
  "بزاز",
  "بعبص",
  "بعص",
  "بغاي",
  "بندوق",
  "بهيمه",
  "تافه",
  "تجليخ",
  "ترهيط",
  "تسد بوزك",
  "تفو",
  "جلخ",
  "جلق",
  "حرامي",
  "حقير",
  "حلبتها",
  "حلبتو",
  "حلمات",
  "حمير",
  "حيوان",
  "خرا",
  "خراء",
  "خراي عل",
  "خراي",
  "خره",
  "خرى",
  "خري",
  "خسيس",
  "خنيث",
  "خوازيق",
  "خول",
  "داشر",
  "داعر",
  "دعاره",
  "دلخ",
  "ديوث",
  "ديود",
  "زامل",
  "زب",
  "زبار",
  "زبر",
  "زبه",
  "زبي",
  "زراط",
  "زق",
  "زناه",
    "زناطير",
  "ساذج",
  "سارموتا",
  "سافل",
  "سرموتا",
  "سفاله",
  "سكسي",
  "سيكس",
  "سيكسي",
  "شرمها",
  "شرموط",
  "شرموطه",
  "شرموطه",
  "شلقه",
  "شلكه",
  "صايع",
  "صياعه",
  "ضرب عشره",
  "طز في",
  "طيز",
  "عاهر",
  "عاهره",
  "عايبه",
  "عبيط",
  "عرص",
  "عكروت",
  "غبي",
  "غتصب",
  "فاجر",
  "فاسق",
  "فجور",
  "فسختها",
  "قحاب",
  "قحب",
  "قحبه",
  "قذر",
  "قضيب",
  "قضيبي",
  "كحبه",
  "كذاب",
  "كس",
  "كسا",
  "كسمك",
  "كسمكم",
  "كسها",
  "كلاب",
  "كلب",
  "كلخر",
  "لحس",
  "لعنه",
  "لقحاب",
  "لوطي",
  "مأجور",
  "مبعوص",
  "متخوزق",
  "متناك",
  "مجنون",
  "مخانيث",
  "مخنث",
  "مدلس",
  "معوهر",
  "مفسوخ",
  "مكسكس",
  "مكوتها",
                  "ممحون",
  "منايك",
  "منيك",
  "منيوك",
  "ناكك",
  "نجس",
  "نذل",
  "نفضك",
  "نفظك",
  "نكت",
  "نياكه",
  "نياكه",
  "وسخ",
  "يتناك",
  "يزغب",
  "يفضح",
  "يفظح",
  "يولاد ال",
  "يلعن",
  "سكس",
  "طيزي",
  "طيزو",
  "شرج",
  "لعق",
  "لحس",
  "مص",
  "تمص",
  "بيضان",
  "ثدي",
  "بز",
  "بزاز",
  "حلمه",
  "مفلقسه",
  "بظر",
  "كس",
  "كسي",
  "فرج",
  "شهوه",
  "شاذ",
  "مبادل",
  "عاهره",
  "جماع",
  "قضيب",
  "زب",
  "لوطي",
  "لواط",
  "سحاق",
  "سحاقيه",
  "اغتصاب",
  "خنثي",
  "احتلام",
  "نيك",
  "متناك",
  "متناكه",
  "شرموطه",
  "عرص",
  "خول",
  "قحبه",
  "لبوه",
  "السكس",
  "الطيز",
  "الطيزي",
  "الطيزو",
  "الشرج",
  "اللعق",
  "اللحس",
  "المص",
  "التمص",
  "البيضان",
  "الثدي",
  "البز",
  "البزاز",
  "الحلمه",
  "المفلقسه",
  "البظر",
  "الكس",
  "الكسي",
  "الفرج",
  "الشهوه",
  "الشاذ",
  "المبادل",
  "العاهره",
  "الجماع",
  "القضيب",
  "الزب",
  "اللوطي",
  "اللواط",
  "السحاق",
  "السحاقيه",
  "الاغتصاب",
  "الخنثي",
  "الخنثي",
  "الاحتلام",
  "النيك",
  "المتناك",
  "المتناكه",
  "الشرموطه",
  "العرص",
  "الخول",
  "القحبه",
  "اللبوه",
  "الفشخه",
  "فشخه",
  "هنيكك",
  "الممحونه",
  "ممحونه",
  "ايري",
  "الاير",
  "بخش",
  "البخش",
  "بخشي",
  "طيزا",
  "عكروت",
  "نايك",
  "انكحك",
  "انتاك",
    "خرايا",
  "ديوث",
  "قواد",
  "يلعن",
  "يلعنك",
  "ملحات",
  "زاكا",
  "صرمك يا خول"
]
    if (bads.some(word => everonemanshort.includes(word))) { 
      const embed = new EmbedBuilder()
        .setColor('#000100')
        .setTitle(`عملية الشراء تم الغاءها`)
        .setDescription(`**تم إلغاء عملية الشراء لأن الرسالة تحتوي على كلمات ممنوعة**`);
      await interaction.reply({
        embeds: [embed],
        ephemeral: true,
      });
    } else {
    const channel = interaction.guild.channels.cache.get(config.manshortchannel);
    
    const embed = new EmbedBuilder()
     .setColor('#000100')
     .setTitle('تم نشر منشورك بنجاح')
     .setDescription("`**تم عمالية الشراء سيتم قفل تكت بعد 3 ثواني .**`")
    
      const row = new ActionRowBuilder()
      .addComponents(
        new ButtonBuilder()
          .setCustomId('2')
          .setLabel('تم شراءك بنجاح')
.setStyle(ButtonStyle.Success)
.setDisabled(true)
      ); 
    await interaction.update({
      components: [row],
      embeds: [embed]
    })
    
    await channel.send({
      content: `${everonemanshort}\nتواصل مع : <@${interaction.user.id}>\n@everyone`
    });
    await channel.send({
      content: `ليس لنا أدنى علاقه بما يحدث بينكم بالخاص كلها منشورات مدفوعه ، لطلب منشور مثله حياك #⌬〢تكتات`
    })
  await interaction.editReply({
    content: `تم ارسال منشورك بنجاح`,
    ephemeral: true })
  setTimeout(async () => {
interaction.channel.delete() 
}, 3000)
      }
     }
  });