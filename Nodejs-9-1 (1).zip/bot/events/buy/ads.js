const client = require("../../index.js");
const { EmbedBuilder, ApplicationCommandOptionType , Events , ActionRowBuilder , ButtonBuilder ,MessageAttachment, ButtonStyle , Message, TextInputStyle,TextInputBuilder,ModalBuilder, StringSelectMenuBuilder, StringSelectMenuOptionBuilder, PermissionsBitField } = require("discord.js");
const users = require('../../Datebase/model/buy.js');
const config = require("../../config.json");

client.on('interactionCreate', async interaction => {
 if (!interaction.isStringSelectMenu()) return;
 if (interaction.customId === 'buy') {
 const selectedValue = interaction.values[0];
 if (selectedValue === 'ads') {
 const mention = new StringSelectMenuBuilder()
 .setCustomId('mention-ads')
 .setPlaceholder('اختر نوع المنشن')
 .addOptions(
 new StringSelectMenuOptionBuilder()
 .setLabel('بدون منشن')
 .setValue('non-ads'),
 new StringSelectMenuOptionBuilder()
 .setLabel('منشن هير')
 .setValue('here-ads'),
 new StringSelectMenuOptionBuilder()
 .setLabel('منشن ايفري')
 .setValue('everyone-ads'),
new StringSelectMenuOptionBuilder()
.setLabel('روم هدايا الاعلانات')
.setValue('inroomgivaway-ads'),
new StringSelectMenuOptionBuilder()
.setLabel('روم خاص بدون قيف اواي')
.setValue('private-ads'),
new StringSelectMenuOptionBuilder()
.setLabel('روم خاص بقيف اواي')
.setValue('private-giveaway-ads'),
 );
 const row = new ActionRowBuilder()
 .addComponents(mention);
   const rd = new ActionRowBuilder()
      .addComponents(
        new ButtonBuilder()
          .setCustomId('can-buy')
          .setLabel('الغاء العمليه')
          .setStyle(ButtonStyle.Danger)
      );
 const embed = new EmbedBuilder()
 .setColor('#000100')
 .setDescription(
 `**اختر نوع المنشن الذي تريده**`)
 await interaction.update({
 embeds: [embed],
 components: [row, rd],
 });

   
 }
 } else if (interaction.customId === 'mention-ads') {
  const selectedValue = interaction.values[0];
  if (selectedValue === 'non-ads') {
         let price = config.price_non_ads;
     let result = price;
     
     let tax = Math.floor(price * (20 / 19) + 1);
     let owner = config.owner;
    const embed = new EmbedBuilder()
      .setColor("#000100")
      .setTitle("**عمليه شراء اعلان بدون منشن**")
      .setDescription(`**لأكمال عملية شراء اعلان بدون منشن , يرجي نسخ الكود بالاسفل واتمام عملية التحويل

 \`\`\`#credit ${owner} ${tax}\`\`\`**`)
    .setAuthor({
             name: interaction.guild.name,
             iconURL: interaction.guild.iconURL()})
             .setFooter({
             text: interaction.guild.name,
               iconURL: interaction.guild.iconURL()
             })

             .setThumbnail(interaction.guild.iconURL())

         .setTimestamp();
     await interaction.update({
       embeds: [embed],
       components: [],
     })
    await interaction.channel.send({
  content: `#credit ${owner} ${tax}`
  })
    const filter = ({ content, author: { id } }) => {
    return (
        content.startsWith(`**:moneybag: | ${interaction.user.username}, has transferred `) &&
        content.includes(`${owner}`) &&
        id === "282859044593598464" &&
        (Number(content.slice(content.lastIndexOf("`") - String(tax).length, content.lastIndexOf("`"))) >= result)
    );
  };
    const collector = interaction.channel.createMessageCollector({ 
  filter,               
  max: 1,
  time: 60000,
  });
  let iscollected = false;
  collector.on('collect', async (collected) => {
  iscollected = true;
  const embed = new EmbedBuilder()
  .setColor('#000100')
  .setTitle(
  `تمت عملية الشراء بنجاح`)
  .setDescription(
  `**تم شراء المنشور المميز بنجاح**`)
  .setAuthor({
             name: interaction.guild.name,
             iconURL: interaction.guild.iconURL()})
             .setFooter({
             text: interaction.guild.name,
               iconURL: interaction.guild.iconURL()
             })

             .setThumbnail(interaction.guild.iconURL())

         .setTimestamp();
      const row = new ActionRowBuilder()
      .addComponents(
        new ButtonBuilder()
          .setCustomId('done-buyads-non')
          .setLabel('قم بوضع اعلانك هنا')
          .setStyle(ButtonStyle.Success)
      );
      await interaction.editReply({
  embeds: [embed],
  components: [row],
  });
const user = await users.deleteOne({ userId: interaction.user.id });
    
});
    
collector.on('end', async (collected) => {
  if (!iscollected) {
  const embed = new EmbedBuilder()
  .setColor('#000100')
  .setTitle(
  `انتهى وقت العمليه`)
  .setDescription(
  `**انتهى وقت العمليه**`)
    .setAuthor({
         name: interaction.guild.name,
         iconURL: interaction.guild.iconURL()})
         .setFooter({
         text: interaction.guild.name,
           iconURL: interaction.guild.iconURL()
         })

         .setThumbnail(interaction.guild.iconURL())

     .setTimestamp();
  await interaction.editReply({
  embeds: [embed],
  components: [],
  });
  const user = await users.deleteOne({ userId: interaction.user.id });
  }
});
    
    } else if (selectedValue === 'here-ads') {
         let price = config.price_here_ads;
     let result = price;
     
     let tax = Math.floor(price * (20 / 19) + 1);
     let owner = config.owner;
    const embed = new EmbedBuilder()
      .setColor("#000100")
      .setTitle(
      `**عمليه شراء اعلان منشن هير**`)
      .setDescription(
      `**لأكمال عملية شراء اعلان منشن هير , يرجي نسخ الكود بالاسفل واتمام عملية التحويل **`)
        .setAuthor({
             name: interaction.guild.name,
             iconURL: interaction.guild.iconURL()})
             .setFooter({
             text: interaction.guild.name,
               iconURL: interaction.guild.iconURL()
             })

             .setThumbnail(interaction.guild.iconURL())

         .setTimestamp();
     await interaction.update({
       embeds: [embed],
       components: [],
     })
    await interaction.channel.send({
  content: `#credit ${owner} ${tax}`
  })
    const filter = ({ content, author: { id } }) => {
    return (
        content.startsWith(`**:moneybag: | ${interaction.user.username}, has transferred `) &&
        content.includes(`${owner}`) &&
        id === "282859044593598464" &&
        (Number(content.slice(content.lastIndexOf("`") - String(tax).length, content.lastIndexOf("`"))) >= result)
    );
  };
    const collector = interaction.channel.createMessageCollector({ 
  filter,               
  max: 1,
  time: 60000,
  });
  let iscollected = false;
  collector.on('collect', async (collected) => {
  iscollected = true;
    const embed = new EmbedBuilder()
  .setColor('#000100')
  .setTitle(
  `تمت عملية الشراء بنجاح`)
  .setDescription(
  `**تم شراء اعلان منشن هير بنجاح**`)
  .setAuthor({
             name: interaction.guild.name,
             iconURL: interaction.guild.iconURL()})
             .setFooter({
             text: interaction.guild.name,
               iconURL: interaction.guild.iconURL()
             })

             .setThumbnail(interaction.guild.iconURL())

         .setTimestamp();
      const row = new ActionRowBuilder()
      .addComponents(
        new ButtonBuilder()
          .setCustomId('done-buyads-here')
          .setLabel('قم بوضع اعلانك هنا')
          .setStyle(ButtonStyle.Success)
      );
      await interaction.editReply({
  embeds: [embed],
  components: [row],
  });
    const user = await users.deleteOne({ userId: interaction.user.id });
    
});
  collector.on('end', async (collected) => {
  if (!iscollected) {
  const embed = new EmbedBuilder()
  .setColor('#000100')
  .setTitle(
  `انتهى وقت العمليه`)
  .setDescription(
  `**انتهى وقت العمليه**`)
    .setAuthor({
         name: interaction.guild.name,
         iconURL: interaction.guild.iconURL()})
         .setFooter({
         text: interaction.guild.name,
           iconURL: interaction.guild.iconURL()
         })

         .setThumbnail(interaction.guild.iconURL())

     .setTimestamp();
  await interaction.editReply({
  embeds: [embed],
  components: [],
  });
  const user = await users.deleteOne({ userId: interaction.user.id });
  }
});
    
    } else if (selectedValue === 'everyone-ads') {
         let price = config.price_everyone_ads;
     let result = price;
     
     let tax = Math.floor(price * (20 / 19) + 1);
     let owner = config.owner;
    const embed = new EmbedBuilder()
      .setColor("#000100")
      .setTitle(
      `**عمليه شراء اعلان منشن ايفري**`)
      .setDescription(
      `**لأكمال عملية شراء اعلان منشن ايفري , يرجي نسخ الكود بالاسفل واتمام عملية التحويل **`)
        .setAuthor({
             name: interaction.guild.name,
             iconURL: interaction.guild.iconURL()})
             .setFooter({
             text: interaction.guild.name,
               iconURL: interaction.guild.iconURL()
             })

             .setThumbnail(interaction.guild.iconURL())

         .setTimestamp();
     await interaction.update({
       embeds: [embed],
       components: [],
     })
    await interaction.channel.send({
  content: `#credit ${owner} ${tax}`
  })
    const filter = ({ content, author: { id } }) => {
    return (
        content.startsWith(`**:moneybag: | ${interaction.user.username}, has transferred `) &&
        content.includes(`${owner}`) &&
        id === "282859044593598464" &&
        (Number(content.slice(content.lastIndexOf("`") - String(tax).length, content.lastIndexOf("`"))) >= result)
    );
  };
    const collector = interaction.channel.createMessageCollector({ 
  filter,               
  max: 1,
  time: 60000,
  });
  let iscollected = false;
  collector.on('collect', async (collected) => {
  iscollected = true;
    const embed = new EmbedBuilder()
  .setColor('#000100')
  .setTitle(
  `تمت عملية الشراء بنجاح`)
  .setDescription(
  `**تم شراء اعلان منشن ايفري بنجاح**`)
  .setAuthor({
             name: interaction.guild.name,
             iconURL: interaction.guild.iconURL()
  })
             .setFooter({
             text: interaction.guild.name,
               iconURL: interaction.guild.iconURL()
             })
             .setThumbnail(interaction.guild.iconURL())
         .setTimestamp();
      const row = new ActionRowBuilder()
      .addComponents(
        new ButtonBuilder()
          .setCustomId('done-buyads-everyone')
          .setLabel('قم بوضع اعلانك هنا')
          .setStyle(ButtonStyle.Success)
      );
      await interaction.editReply({
  embeds: [embed],
  components: [row],
      });
    const user = await users.deleteOne({ userId: interaction.user.id });
    
});
    collector.on('end', async (collected) => {
  if (!iscollected) {
  const embed = new EmbedBuilder()
  .setColor('#000100')
  .setTitle(
  `انتهى وقت العمليه`)
  .setDescription(
  `**انتهى وقت العمليه**`)
    .setAuthor({
         name: interaction.guild.name,
         iconURL: interaction.guild.iconURL()})
         .setFooter({
         text: interaction.guild.name,
           iconURL: interaction.guild.iconURL()
         })

         .setThumbnail(interaction.guild.iconURL())

     .setTimestamp();
  await interaction.editReply({
  embeds: [embed],
  components: [],
  });
  const user = await users.deleteOne({ userId: interaction.user.id });
  }
});

    
    } else if (selectedValue === 'inroomgivaway-ads') {
         let price = config.price_in_room_givaway_ads;
     let result = price;
     
     let tax = Math.floor(price * (20 / 19) + 1);
     let owner = config.owner;
    const embed = new EmbedBuilder()
      .setColor("#000100")
      .setTitle(
      `**عمليه شراء اعلان قيف اوي في روم**`)
      .setDescription(
      `**لأكمال عملية شراء اعلان قيف اوي في روم , يرجي نسخ الكود بالاسفل واتمام عملية التحويل **`)
               .setAuthor({
             name: interaction.guild.name,
             iconURL: interaction.guild.iconURL()})
             .setFooter({
             text: interaction.guild.name,
               iconURL: interaction.guild.iconURL()
             })

             .setThumbnail(interaction.guild.iconURL())

         .setTimestamp();
     await interaction.update({
       embeds: [embed],
       components: [],
     })
    await interaction.channel.send({
  content: `#credit ${owner} ${tax}` })
    const filter = ({ content, author: { id } }) => {
    return (
        content.startsWith(`**:moneybag: | ${interaction.user.username}, has transferred `) &&
        content.includes(`${owner}`) &&
        id === "282859044593598464" &&
        (Number(content.slice(content.lastIndexOf("`") - String(tax).length, content.lastIndexOf("`"))) >= result)
    );
  };
   const collector = interaction.channel.createMessageCollector({ 
  filter,               
  max: 1,
  time: 60000,
  });
  let iscollected = false;
  collector.on('collect', async (collected) => {
  iscollected = true;
    const embed = new EmbedBuilder()
  .setColor('#000100')
  .setTitle(
  `تمت عملية الشراء بنجاح`)
  .setDescription(
  `**تم شراء اعلان قيف اوي في روم الجيف اواي**`)
         .setAuthor({
             name: interaction.guild.name,
             iconURL: interaction.guild.iconURL()})
             .setFooter({
             text: interaction.guild.name,
               iconURL: interaction.guild.iconURL()
             })

             .setThumbnail(interaction.guild.iconURL())

         .setTimestamp();
      const row = new ActionRowBuilder()
      .addComponents(
        new ButtonBuilder()
          .setCustomId('done-buyads-inroom')
          .setLabel('قم بوضع اعلانك هنا')
          .setStyle(ButtonStyle.Success)
      );
      await interaction.editReply({
  embeds: [embed],
  components: [row],
      })
    const user = await users.deleteOne({ userId: interaction.user.id });
});

          collector.on('end', async (collected) => {
  if (!iscollected) {
  const embed = new EmbedBuilder()
  .setColor('#000100')
  .setTitle(
  `انتهى وقت العمليه`)
  .setDescription(
  `**انتهى وقت العمليه**`)
    .setAuthor({
         name: interaction.guild.name,
         iconURL: interaction.guild.iconURL()})
         .setFooter({
         text: interaction.guild.name,
           iconURL: interaction.guild.iconURL()
         })

         .setThumbnail(interaction.guild.iconURL())

     .setTimestamp();
  await interaction.editReply({
  embeds: [embed],
  components: [],
  });
  const user = await users.deleteOne({ userId: interaction.user.id });
  }
});
      
    } else if (selectedValue === 'private-ads') {
         let price = config.price_private_ads;
     let result = price;
     
     let tax = Math.floor(price * (20 / 19) + 1);
     let owner = config.owner;
    const embed = new EmbedBuilder()
      .setColor("#000100")
      .setTitle(
      `**عمليه شراء اعلان خاص**`)
      .setDescription(
      `**لأكمال عملية شراء اعلان خاص , يرجي نسخ الكود بالاسفل واتمام عملية التحويل **`)
                      .setAuthor({
             name: interaction.guild.name,
             iconURL: interaction.guild.iconURL()})
             .setFooter({
             text: interaction.guild.name,
               iconURL: interaction.guild.iconURL()
             })

             .setThumbnail(interaction.guild.iconURL())

         .setTimestamp();
     await interaction.update({
       embeds: [embed],
       components: [],
     })
    await interaction.channel.send({
  content: `#credit ${owner} ${tax}` })

    const filter = ({ content, author: { id } }) => {
    return (
        content.startsWith(`**:moneybag: | ${interaction.user.username}, has transferred `) &&
        content.includes(`${owner}`) &&
        id === "282859044593598464" &&
        (Number(content.slice(content.lastIndexOf("`") - String(tax).length, content.lastIndexOf("`"))) >= result)
    );
  };
    const collector = interaction.channel.createMessageCollector({ 
  filter,               
  max: 1,
  time: 60000,
  });
  let iscollected = false;
  collector.on('collect', async (collected) => {
  iscollected = true;
    const embed = new EmbedBuilder()
  .setColor('#000100')
  .setTitle(
  `تمت عملية الشراء بنجاح`)
  .setDescription(
  `**تم شراء اعلان خاص بنجاح**`)
                .setAuthor({
             name: interaction.guild.name,
             iconURL: interaction.guild.iconURL()})
             .setFooter({
             text: interaction.guild.name,
               iconURL: interaction.guild.iconURL()
             })

             .setThumbnail(interaction.guild.iconURL())

         .setTimestamp();
      const row = new ActionRowBuilder()
      .addComponents(
        new ButtonBuilder()
          .setCustomId('done-buyads-private')
          .setLabel('قم بوضع اعلانك هنا')
          .setStyle(ButtonStyle.Success)
      );
      await interaction.editReply({
  embeds: [embed],
  components: [row],
      })
    const user = await users.deleteOne({ userId: interaction.user.id });
});
        collector.on('end', async (collected) => {
  if (!iscollected) {
  const embed = new EmbedBuilder()
  .setColor('#000100')
  .setTitle(
  `انتهى وقت العمليه`)
  .setDescription(
  `**انتهى وقت العمليه**`)
    .setAuthor({
         name: interaction.guild.name,
         iconURL: interaction.guild.iconURL()})
         .setFooter({
         text: interaction.guild.name,
           iconURL: interaction.guild.iconURL()
         })

         .setThumbnail(interaction.guild.iconURL())

     .setTimestamp();
  await interaction.editReply({
  embeds: [embed],
  components: [],
  });
  const user = await users.deleteOne({ userId: interaction.user.id });
  }
});
      

      
    
    } else if (selectedValue === 'private-giveaway-ads') {
         let price = config.price_private_giveaway_ads;
     let result = price;
     
     let tax = Math.floor(price * (20 / 19) + 1);
     let owner = config.owner; 
    const embed = new EmbedBuilder()
      .setColor("#000100")
      .setTitle(
      `**عمليه شراء اعلان قيف اوي خاص**`)
      .setDescription(
      `**لأكمال عملية شراء اعلان قيف اوي خاص , يرجي نسخ الكود بالاسفل واتمام عملية التحويل **`)
           .setAuthor({
             name: interaction.guild.name,
             iconURL: interaction.guild.iconURL()})
             .setFooter({
             text: interaction.guild.name,
               iconURL: interaction.guild.iconURL()
             })

             .setThumbnail(interaction.guild.iconURL())

         .setTimestamp();
     await interaction.update({
       embeds: [embed],
       components: [],
     })
    await interaction.channel.send({
  content: `#credit ${owner} ${tax}` })
  const filter = ({ content, author: { id } }) => {
    return (
        content.startsWith(`**:moneybag: | ${interaction.user.username}, has transferred `) &&
        content.includes(`${owner}`) &&
        id === "282859044593598464" &&
        (Number(content.slice(content.lastIndexOf("`") - String(tax).length, content.lastIndexOf("`"))) >= result)
    );
  };
    const collector = interaction.channel.createMessageCollector({ 
  filter,               
  max: 1,
  time: 60000,
  });
  let iscollected = false;
  collector.on('collect', async (collected) => {
  iscollected = true;
    const embed = new EmbedBuilder()
  .setColor('#000100')
  .setTitle(
  `تمت عملية الشراء بنجاح`)
  .setDescription(
  `**تم شراء اعلان قيف اوي خاص بنجاح**`)
           .setAuthor({
             name: interaction.guild.name,
             iconURL: interaction.guild.iconURL()})
             .setFooter({
             text: interaction.guild.name,
               iconURL: interaction.guild.iconURL()
             })

             .setThumbnail(interaction.guild.iconURL())

         .setTimestamp();
      const row = new ActionRowBuilder()
      .addComponents(
        new ButtonBuilder()
          .setCustomId('done-buyads-private-giveaway')
          .setLabel('قم بوضع اعلانك هنا')
          .setStyle(ButtonStyle.Success)
      );
      await interaction.editReply({
  embeds: [embed],
  components: [row],
      })
    const user = await users.deleteOne({ userId: interaction.user.id });
});
        collector.on('end', async (collected) => {
  if (!iscollected) {
  const embed = new EmbedBuilder()
  .setColor('#000100')
  .setTitle(
  `انتهى وقت العمليه`)
  .setDescription(
  `**انتهى وقت العمليه**`)
    .setAuthor({
         name: interaction.guild.name,
         iconURL: interaction.guild.iconURL()})
         .setFooter({
         text: interaction.guild.name,
           iconURL: interaction.guild.iconURL()
         })

         .setThumbnail(interaction.guild.iconURL())

     .setTimestamp();
  await interaction.editReply({
  embeds: [embed],
  components: [],
  });
  const user = await users.deleteOne({ userId: interaction.user.id });
  }
});
    }
  }
});