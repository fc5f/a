const client = require("../../index.js");
const { EmbedBuilder } = require('discord.js');
client.on('interactionCreate', async (interaction) => {
  if (!interaction.isButton()) return;
  if (interaction.customId === 'done') {
    
  }
});