const client = require("../../index.js");
const { EmbedBuilder, ApplicationCommandOptionType , Events , ActionRowBuilder , ButtonBuilder ,MessageAttachment, ButtonStyle , Message, TextInputStyle,TextInputBuilder,ModalBuilder, StringSelectMenuBuilder, StringSelectMenuOptionBuilder, PermissionsBitField } = require("discord.js");
client.on('interactionCreate', async interaction => {
  if (!interaction.isButton()) return;
  if (interaction.customId === 'Sample') {
    const modal = new ModalBuilder()
      .setCustomId('mediator_modal1')
      .setTitle('بيانات طلب وسيط تجريبي')
    const seller_id = new TextInputBuilder()
      .setCustomId('seller_id')
      .setLabel("ايدي البائع :")
.setStyle(TextInputStyle.Short)
      .setRequired(true)
    .setPlaceholder('حط ايدي البائع هنا :');
    const buyer_id = new TextInputBuilder()
      .setCustomId('buyer_id')
      .setLabel("ايدي المشتري :")
.setStyle(TextInputStyle.Short)
      .setRequired(true)
    .setPlaceholder('حط ايدي المشتري هنا :');
    const items_buy = new TextInputBuilder()
      .setCustomId('items_buy')
      .setLabel("ما هي السلعه :")
.setStyle(TextInputStyle.Paragraph)
      .setRequired(true)
    .setPlaceholder('كمثال : نيترو قفت');
    const price = new TextInputBuilder()
      .setCustomId("item_price")
      .setLabel("كم سعر السلعه؟ :")
.setStyle(TextInputStyle.Short)
      .setRequired(true)
    .setPlaceholder('400k فما اقل');
    const Medianratio = new TextInputBuilder()
      .setCustomId("Medianratio")
      .setLabel("نسبه الوسيط علي مين؟ :")
.setStyle(TextInputStyle.Short)
      .setRequired(true)
    .setPlaceholder('نسبه الوسيط علي مين؟');
    const firstActionRow = new ActionRowBuilder().addComponents(seller_id);
    const secondActionRow = new ActionRowBuilder().addComponents(buyer_id);
    const thirdActionRow = new ActionRowBuilder().addComponents(items_buy);
    const fourthActionRow = new ActionRowBuilder().addComponents(price);
    const fifthActionRow = new ActionRowBuilder().addComponents(Medianratio);
    modal.addComponents(firstActionRow, secondActionRow, thirdActionRow, fourthActionRow, fifthActionRow)
    await interaction.showModal(modal);
  } else if (interaction.customId === 'Sample2') {
    const modal = new ModalBuilder()
      .setCustomId('mediator_modal2')
      .setTitle('بيانات طلب وسيط مبتدئ')
    const seller_id = new TextInputBuilder()
      .setCustomId('seller_id')
      .setLabel("ايدي البائع :")
.setStyle(TextInputStyle.Short)
      .setRequired(true)
    .setPlaceholder('حط ايدي البائع هنا :');
    const buyer_id = new TextInputBuilder()
      .setCustomId('buyer_id')
      .setLabel("ايدي المشتري :")
.setStyle(TextInputStyle.Short)
      .setRequired(true)
    .setPlaceholder('حط ايدي المشتري هنا :');
    const items_buy = new TextInputBuilder()
      .setCustomId('items_buy')
      .setLabel("ما هي السلعه :")
.setStyle(TextInputStyle.Paragraph)
      .setRequired(true)
    .setPlaceholder('كمثال : نيترو قفت');
      const price = new TextInputBuilder()
      .setCustomId("item_price")
      .setLabel("كم سعر السلعه؟ :")
.setStyle(TextInputStyle.Short)
      .setRequired(true)
    .setPlaceholder('600k فما اقل');
    const Medianratio = new TextInputBuilder()
      .setCustomId("Medianratio")
      .setLabel("نسبه الوسيط علي مين؟ :")
.setStyle(TextInputStyle.Short)
      .setRequired(true)
    .setPlaceholder('نسبه الوسيط علي مين؟');
    const firstActionRow = new ActionRowBuilder().addComponents(seller_id);
    const secondActionRow = new ActionRowBuilder().addComponents(buyer_id);
    const thirdActionRow = new ActionRowBuilder().addComponents(items_buy);
    const fourthActionRow = new ActionRowBuilder().addComponents(price);
    const fifthActionRow = new ActionRowBuilder().addComponents(Medianratio);
    modal.addComponents(firstActionRow, secondActionRow, thirdActionRow, fourthActionRow, fifthActionRow)
    await interaction.showModal(modal);
  } else if (interaction.customId === 'Sample3') {
    const modal = new ModalBuilder()
      .setCustomId('mediator_modal3')
      .setTitle('بيانات طلب وسيط متوسط')
    const seller_id = new TextInputBuilder()
      .setCustomId('seller_id')
      .setLabel("ايدي البائع :")
.setStyle(TextInputStyle.Short)
      .setRequired(true)
    .setPlaceholder('حط ايدي البائع هنا :');
    const buyer_id = new TextInputBuilder()
      .setCustomId('buyer_id')
      .setLabel("ايدي المشتري :")
.setStyle(TextInputStyle.Short)
      .setRequired(true)
    .setPlaceholder('حط ايدي المشتري هنا :');
    const items_buy = new TextInputBuilder()
      .setCustomId('items_buy')
      .setLabel("ما هي السلعه :")
.setStyle(TextInputStyle.Paragraph)
      .setRequired(true)
    .setPlaceholder('كمثال : نيترو قفت');
      const price = new TextInputBuilder()
      .setCustomId("item_price")
      .setLabel("كم سعر السلعه؟ :")
.setStyle(TextInputStyle.Short)
      .setRequired(true)
    .setPlaceholder('800k فما اقل');
    const Medianratio = new TextInputBuilder()
      .setCustomId("Medianratio")
      .setLabel("نسبه الوسيط علي مين؟ :")
.setStyle(TextInputStyle.Short)
      .setRequired(true)
    .setPlaceholder('نسبه الوسيط علي مين؟');
    const firstActionRow = new ActionRowBuilder().addComponents(seller_id);
    const secondActionRow = new ActionRowBuilder().addComponents(buyer_id);
    const thirdActionRow = new ActionRowBuilder().addComponents(items_buy);
    const fourthActionRow = new ActionRowBuilder().addComponents(price);
    const fifthActionRow = new ActionRowBuilder().addComponents(Medianratio);
    modal.addComponents(firstActionRow, secondActionRow, thirdActionRow, fourthActionRow, fifthActionRow)
    await interaction.showModal(modal);
  } else if (interaction.customId === 'Sample4') {
    const modal = new ModalBuilder()
      .setCustomId('mediator_modal4')
      .setTitle('بيانات طلب وسيط معتمد')
    const seller_id = new TextInputBuilder()
      .setCustomId('seller_id')
      .setLabel("ايدي البائع :")
.setStyle(TextInputStyle.Short)
      .setRequired(true)
    .setPlaceholder('حط ايدي البائع هنا :');
    const buyer_id = new TextInputBuilder()
      .setCustomId('buyer_id')
      .setLabel("ايدي المشتري :")
.setStyle(TextInputStyle.Short)
      .setRequired(true)
    .setPlaceholder('حط ايدي المشتري هنا :');
    const items_buy = new TextInputBuilder()
      .setCustomId('items_buy')
      .setLabel("ما هي السلعه :")
.setStyle(TextInputStyle.Paragraph)
      .setRequired(true)
    .setPlaceholder('كمثال : نيترو قفت');
      const price = new TextInputBuilder()
      .setCustomId("item_price")
      .setLabel("كم سعر السلعه؟ :")
.setStyle(TextInputStyle.Short)
      .setRequired(true)
    .setPlaceholder('1.6m فما اقل');
    const Medianratio = new TextInputBuilder()
      .setCustomId("Medianratio")
      .setLabel("نسبه الوسيط علي مين؟ :")
.setStyle(TextInputStyle.Short)
      .setRequired(true)
    .setPlaceholder('نسبه الوسيط علي مين؟');
    const firstActionRow = new ActionRowBuilder().addComponents(seller_id);
    const secondActionRow = new ActionRowBuilder().addComponents(buyer_id);
    const thirdActionRow = new ActionRowBuilder().addComponents(items_buy);
    const fourthActionRow = new ActionRowBuilder().addComponents(price);
    const fifthActionRow = new ActionRowBuilder().addComponents(Medianratio);
    modal.addComponents(firstActionRow, secondActionRow, thirdActionRow, fourthActionRow, fifthActionRow)
    await interaction.showModal(modal);
  } else if (interaction.customId === 'Sample5') {
    const modal = new ModalBuilder()
      .setCustomId('mediator_modal5')
      .setTitle('بيانات طلب وسيط موثوق')
    const seller_id = new TextInputBuilder()
      .setCustomId('seller_id')
      .setLabel("ايدي البائع :")
.setStyle(TextInputStyle.Short)
      .setRequired(true)
    .setPlaceholder('حط ايدي البائع هنا :');
    const buyer_id = new TextInputBuilder()
      .setCustomId('buyer_id')
      .setLabel("ايدي المشتري :")
.setStyle(TextInputStyle.Short)
      .setRequired(true)
    .setPlaceholder('حط ايدي المشتري هنا :');
    const items_buy = new TextInputBuilder()
      .setCustomId('items_buy')
      .setLabel("ما هي السلعه :")
.setStyle(TextInputStyle.Paragraph)
      .setRequired(true)
    .setPlaceholder('كمثال : نيترو قفت');
      const price = new TextInputBuilder()
      .setCustomId("item_price")
      .setLabel("كم سعر السلعه؟ :")
.setStyle(TextInputStyle.Short)
      .setRequired(true)
    .setPlaceholder('3.2m فما اقل');
    const Medianratio = new TextInputBuilder()
      .setCustomId("Medianratio")
      .setLabel("نسبه الوسيط علي مين؟ :")
.setStyle(TextInputStyle.Short)
      .setRequired(true)
    .setPlaceholder('نسبه الوسيط علي مين؟');
    const firstActionRow = new ActionRowBuilder().addComponents(seller_id);
    const secondActionRow = new ActionRowBuilder().addComponents(buyer_id);
    const thirdActionRow = new ActionRowBuilder().addComponents(items_buy);
    const fourthActionRow = new ActionRowBuilder().addComponents(price);
    const fifthActionRow = new ActionRowBuilder().addComponents(Medianratio);
    modal.addComponents(firstActionRow, secondActionRow, thirdActionRow, fourthActionRow, fifthActionRow)
    await interaction.showModal(modal);
  }
});
client.on('interactionCreate', async (interaction) => {
  if (!interaction.isModalSubmit()) return;
  if (interaction.customId === 'mediator_modal1') {
    const seller_id = interaction.fields.getTextInputValue('seller_id');
    const buyer_id = interaction.fields.getTextInputValue('buyer_id');
    const items_buy = interaction.fields.getTextInputValue('items_buy');
    const price = interaction.fields.getTextInputValue('item_price');
    const Medianratio = interaction.fields.getTextInputValue('Medianratio');
    const embed = new EmbedBuilder()
      .setColor('#000100')
      .setTitle('طلب وسيط مبتدا')
      .setDescription(`- **مرحبا بك , يرجى الانتظار تم تبليغ وتنبيهم برؤية تيكت يرجى عدم ازعاج الوسطاء**
- **يجب عليك احترام الوسيط ويجب عليك مراجعة قوانين التوسط ويحق لك ان تقوم بمنشن الوسيط كل 6 دقائق لآ غير.**
- **يرجى الاتفاق مع الطرف الآخر عن السـعر والســلعه وجميع الاشياء الضرورية . تذكر دائما الوسيط لخدمتك وعدم تعرضك لـ النهب .**
- **ويجب علينا تقديره على الذي يقوم به ويرجى عدم التكبر على الوسيط.**
- **السب او قِلت الآداب على الوسيط او داخل التذكرة لن نتقبل العذر وقد تصل العقوبة الى الباند المؤبد.**
- **وتذكر دائما نحن هنا لخدمتك .. ريدبول**`)
    .setAuthor({
      name: interaction.guild.name,
      iconURL: interaction.guild.iconURL()})
      .setFooter({
      text: interaction.guild.name,
        iconURL: interaction.guild.iconURL()
      })

      .setThumbnail(interaction.guild.iconURL())
    .setTimestamp();
    const e = new EmbedBuilder()
      .setColor('#000100')
.setDescription(`**ايدي البائع : ${seller_id}**\n**ايدي المشتري : ${buyer_id}**\n**السلعه : ${items_buy}**\n**السعر : ${price}**\n**نسبه الوسيط علي مين : ${Medianratio}**`);
    const row = new ActionRowBuilder()
      .addComponents(
        new ButtonBuilder()
          .setCustomId('mediator_delete')
          .setLabel('اغلاق التذكره')
          .setStyle(ButtonStyle.Danger),
        new ButtonBuilder()
          .setCustomId("mediator_claim")
          .setLabel("استلام التذكره")
        .setStyle(ButtonStyle.Secondary),
        new ButtonBuilder()
          .setCustomId("mediator_help")
          .setLabel("مساعده الوسطاء")
        .setStyle(ButtonStyle.Secondary),
        new ButtonBuilder()
          .setCustomId("done")
          .setLabel("تم التوسط")
        .setStyle(ButtonStyle.Secondary)
      );
    await interaction.reply({ content: 'تم ارسال الطلب بنجاح', ephemeral: true });
    await interaction.message.edit({ embeds: [embed, e], components: [row] });
  } else if (interaction.customId === 'mediator_modal2') {
    const seller_id = interaction.fields.getTextInputValue('seller_id');
    const buyer_id = interaction.fields.getTextInputValue('buyer_id');
    const items_buy = interaction.fields.getTextInputValue('items_buy');
    const price = interaction.fields.getTextInputValue('item_price');
    const Medianratio = interaction.fields.getTextInputValue('Medianratio');
    const embed = new EmbedBuilder()
      .setColor('#000100')
      .setTitle('طلب وسيط تجريبي')
      .setDescription(`- **مرحبا بك , يرجى الانتظار تم تبليغ وتنبيهم برؤية تيكت يرجى عدم ازعاج الوسطاء**
- **يجب عليك احترام الوسيط ويجب عليك مراجعة قوانين التوسط ويحق لك ان تقوم بمنشن الوسيط كل 6 دقائق لآ غير.**
- **يرجى الاتفاق مع الطرف الآخر عن السـعر والســلعه وجميع الاشياء الضرورية . تذكر دائما الوسيط لخدمتك وعدم تعرضك لـ النهب .**
- **ويجب علينا تقديره على الذي يقوم به ويرجى عدم التكبر على الوسيط.**
- **السب او قِلت الآداب على الوسيط او داخل التذكرة لن نتقبل العذر وقد تصل العقوبة الى الباند المؤبد.**
- **وتذكر دائما نحن هنا لخدمتك .. ريدبول**`)
    .setAuthor({
      name: interaction.guild.name,
      iconURL: interaction.guild.iconURL()})
      .setFooter({
      text: interaction.guild.name,
        iconURL: interaction.guild.iconURL()
      })

      .setThumbnail(interaction.guild.iconURL())
    .setTimestamp();
    const e = new EmbedBuilder()
      .setColor('#000100')
.setDescription(`**ايدي البائع : ${seller_id}**\n**ايدي المشتري : ${buyer_id}**\n**السلعه : ${items_buy}**\n**السعر : ${price}**\n**نسبه الوسيط علي مين : ${Medianratio}**`);
    const row = new ActionRowBuilder()
      .addComponents(
        new ButtonBuilder()
          .setCustomId('mediator_delete')
          .setLabel('اغلاق التذكره')
          .setStyle(ButtonStyle.Danger),
        new ButtonBuilder()
          .setCustomId("mediator_claim")
          .setLabel("استلام التذكره")
        .setStyle(ButtonStyle.Secondary),
        new ButtonBuilder()
          .setCustomId("mediator_help")
.setLabel("مساعده الوسطاء")
.setStyle(ButtonStyle.Secondary),
        new ButtonBuilder()
          .setCustomId("done")
          .setLabel("تم التوسط")
        .setStyle(ButtonStyle.Secondary)
      );
    await interaction.reply({ content: 'تم ارسال الطلب بنجاح', ephemeral: true });
    await interaction.message.edit({ embeds: [embed, e], components: [row] });
  } else if (interaction.customId === 'mediator_modal3') {
    const seller_id = interaction.fields.getTextInputValue('seller_id');
    const buyer_id = interaction.fields.getTextInputValue('buyer_id');
    const items_buy = interaction.fields.getTextInputValue('items_buy');
    const price = interaction.fields.getTextInputValue('item_price');
    const Medianratio = interaction.fields.getTextInputValue('Medianratio');
    const embed = new EmbedBuilder()
      .setColor('#000100')
      .setTitle('طلب وسيط المتوسط')
      .setDescription(`- **مرحبا بك , يرجى الانتظار تم تبليغ وتنبيهم برؤية تيكت يرجى عدم ازعاج الوسطاء**
- **يجب عليك احترام الوسيط ويجب عليك مراجعة قوانين التوسط ويحق لك ان تقوم بمنشن الوسيط كل 6 دقائق لآ غير.**
- **يرجى الاتفاق مع الطرف الآخر عن السـعر والســلعه وجميع الاشياء الضرورية . تذكر دائما الوسيط لخدمتك وعدم تعرضك لـ النهب .**
- **ويجب علينا تقديره على الذي يقوم به ويرجى عدم التكبر على الوسيط.**
- **السب او قِلت الآداب على الوسيط او داخل التذكرة لن نتقبل العذر وقد تصل العقوبة الى الباند المؤبد.**
- **وتذكر دائما نحن هنا لخدمتك .. ريدبول**`)
    .setAuthor({
      name: interaction.guild.name,
      iconURL: interaction.guild.iconURL()})
      .setFooter({
      text: interaction.guild.name,
        iconURL: interaction.guild.iconURL()
      })

      .setThumbnail(interaction.guild.iconURL())
    .setTimestamp();
    const e = new EmbedBuilder()
      .setColor('#000100')
.setDescription(`**ايدي البائع : ${seller_id}**\n**ايدي المشتري : ${buyer_id}**\n**السلعه : ${items_buy}**\n**السعر : ${price}**\n**نسبه الوسيط علي مين : ${Medianratio}**`);
    const row = new ActionRowBuilder()
      .addComponents(
        new ButtonBuilder()
          .setCustomId('mediator_delete')
          .setLabel('اغلاق التذكره')
          .setStyle(ButtonStyle.Danger),
        new ButtonBuilder()
          .setCustomId("mediator_claim")
          .setLabel("استلام التذكره")
        .setStyle(ButtonStyle.Secondary),
        new ButtonBuilder()
          .setCustomId("mediator_help")
          .setLabel("مساعده الوسطاء")
        .setStyle(ButtonStyle.Secondary),
        new ButtonBuilder()
          .setCustomId("done")
          .setLabel("تم التوسط")
        .setStyle(ButtonStyle.Secondary)
      );
    await interaction.reply({ content: 'تم ارسال الطلب بنجاح', ephemeral: true });
    await interaction.message.edit({ embeds: [embed, e], components: [row] });
  } else if (interaction.customId === 'mediator_modal4') {
    const seller_id = interaction.fields.getTextInputValue('seller_id');
    const buyer_id = interaction.fields.getTextInputValue('buyer_id');
    const items_buy = interaction.fields.getTextInputValue('items_buy');
    const price = interaction.fields.getTextInputValue('item_price');
    const Medianratio = interaction.fields.getTextInputValue('Medianratio');
    const embed = new EmbedBuilder()
      .setColor('#000100')
      .setTitle('طلب وسيط معتمد')
      .setDescription(`- **مرحبا بك , يرجى الانتظار تم تبليغ وتنبيهم برؤية تيكت يرجى عدم ازعاج الوسطاء**
- **يجب عليك احترام الوسيط ويجب عليك مراجعة قوانين التوسط ويحق لك ان تقوم بمنشن الوسيط كل 6 دقائق لآ غير.**
- **يرجى الاتفاق مع الطرف الآخر عن السـعر والســلعه وجميع الاشياء الضرورية . تذكر دائما الوسيط لخدمتك وعدم تعرضك لـ النهب .**
- **ويجب علينا تقديره على الذي يقوم به ويرجى عدم التكبر على الوسيط.**
- **السب او قِلت الآداب على الوسيط او داخل التذكرة لن نتقبل العذر وقد تصل العقوبة الى الباند المؤبد.**
- **وتذكر دائما نحن هنا لخدمتك .. ريدبول**`)
    .setAuthor({
      name: interaction.guild.name,
      iconURL: interaction.guild.iconURL()})
      .setFooter({
      text: interaction.guild.name,
        iconURL: interaction.guild.iconURL()
      })

      .setThumbnail(interaction.guild.iconURL())
    .setTimestamp();
    const e = new EmbedBuilder()
      .setColor('#000100')
.setDescription(`**ايدي البائع : ${seller_id}**\n**ايدي المشتري : ${buyer_id}**\n**السلعه : ${items_buy}**\n**السعر : ${price}**\n**نسبه الوسيط علي مين : ${Medianratio}**`);
    const row = new ActionRowBuilder()
      .addComponents(
        new ButtonBuilder()
          .setCustomId('mediator_delete')
          .setLabel('اغلاق التذكره')
          .setStyle(ButtonStyle.Danger),
        new ButtonBuilder()
          .setCustomId("mediator_claim")
          .setLabel("استلام التذكره")
        .setStyle(ButtonStyle.Secondary),
        new ButtonBuilder()
          .setCustomId("mediator_help")
          .setLabel("مساعده الوسطاء")
        .setStyle(ButtonStyle.Secondary),
        new ButtonBuilder()
          .setCustomId("done")
          .setLabel("تم التوسط")
        .setStyle(ButtonStyle.Secondary)
      );
    await interaction.reply({ content: 'تم ارسال الطلب بنجاح', ephemeral: true });
    await interaction.message.edit({ embeds: [embed, e], components: [row] });
  } else if (interaction.customId === 'mediator_modal5') {
    const seller_id = interaction.fields.getTextInputValue('seller_id');
    const buyer_id = interaction.fields.getTextInputValue('buyer_id');
    const items_buy = interaction.fields.getTextInputValue('items_buy');
    const price = interaction.fields.getTextInputValue('item_price');
    const Medianratio = interaction.fields.getTextInputValue('Medianratio');
    const embed = new EmbedBuilder()
      .setColor('#000100')
      .setTitle('طلب وسيط موثوق')
      .setDescription(`- **مرحبا بك , يرجى الانتظار تم تبليغ وتنبيهم برؤية تيكت يرجى عدم ازعاج الوسطاء**
- **يجب عليك احترام الوسيط ويجب عليك مراجعة قوانين التوسط ويحق لك ان تقوم بمنشن الوسيط كل 6 دقائق لآ غير.**
- **يرجى الاتفاق مع الطرف الآخر عن السـعر والســلعه وجميع الاشياء الضرورية . تذكر دائما الوسيط لخدمتك وعدم تعرضك لـ النهب .**
- **ويجب علينا تقديره على الذي يقوم به ويرجى عدم التكبر على الوسيط.**
- **السب او قِلت الآداب على الوسيط او داخل التذكرة لن نتقبل العذر وقد تصل العقوبة الى الباند المؤبد.**
- **وتذكر دائما نحن هنا لخدمتك .. ريدبول**`)
    .setAuthor({
      name: interaction.guild.name,
      iconURL: interaction.guild.iconURL()})
      .setFooter({
      text: interaction.guild.name,
        iconURL: interaction.guild.iconURL()
      })

      .setThumbnail(interaction.guild.iconURL())
    .setTimestamp();
    const e = new EmbedBuilder()
      .setColor('#000100')
.setDescription(`**ايدي البائع : ${seller_id}**\n**ايدي المشتري : ${buyer_id}**\n**السلعه : ${items_buy}**\n**السعر : ${price}**\n**نسبه الوسيط علي مين : ${Medianratio}**`);
    const row = new ActionRowBuilder()
      .addComponents(
        new ButtonBuilder()
          .setCustomId('mediator_delete')
          .setLabel('اغلاق التذكره')
          .setStyle(ButtonStyle.Danger),
        new ButtonBuilder()
          .setCustomId("mediator_claim")
          .setLabel("استلام التذكره")
        .setStyle(ButtonStyle.Secondary),
        new ButtonBuilder()
          .setCustomId("mediator_help")
          .setLabel("مساعده الوسطاء")
        .setStyle(ButtonStyle.Secondary),
        new ButtonBuilder()
          .setCustomId("done")
          .setLabel("تم التوسط")
        .setStyle(ButtonStyle.Secondary)
      );
    await interaction.reply({ content: 'تم ارسال الطلب بنجاح', ephemeral: true });
    await interaction.message.edit({ embeds: [embed, e], components: [row] });
  }
});