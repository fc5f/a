const client = require("../../index.js");
const { EmbedBuilder, ActionRowBuilder, ButtonBuilder, ButtonStyle } = require("discord.js");
const apply = require("../../Datebase/model/apply/support_apply.js");
client.on("interactionCreate", async (interaction) => {
  if (interaction.isButton()) {
    if (interaction.customId === "accept_support") {
        if (!interaction.member.roles.cache.has("1224829322926227640")) return interaction.reply({ content: `You don't have permission to use this button.`, ephemeral: true })
      const member = interaction.message.content.slice(2, 20);
      const user = interaction.guild.members.cache.get(member);
        const channel = interaction.guild.channels.cache.get("1226483877770563606");
      user.roles.add("1226500959849680896").catch((e) => console.log(e));
      const embed = new EmbedBuilder()
        .setTitle("تم قبولك")
        .setDescription(`تم قبولك كـ اداري بسيرفر ريدبول 
 حياك للتعليم و الأختبار ( #❃〢تكت・التعليم)`)
        .setColor("#000100")

.setAuthor({
            name: interaction.guild.name,
            iconURL: interaction.guild.iconURL()
          })
          .setFooter({
            text: interaction.guild.name,
            iconURL: interaction.guild.iconURL()
          })
          .setThumbnail(interaction.guild.iconURL())
        .setTimestamp();
      await channel.send({
       content: `> <@${member}>`,
       embeds: [embed]
      });
      
      
      
      await interaction.reply({
        content: `تم قبول <@${member}> كـ اداري بسيرفر ريدبول`,
        ephemeral: true,
      })
            const row = new ActionRowBuilder()
      .addComponents(
        new ButtonBuilder()
          .setCustomId('accept_mediator')
          .setLabel(`تم قبول المقدم من قبل ${interaction.user.tag}`)
        .setDisabled(true)
.setStyle(ButtonStyle.Success),
        new ButtonBuilder()
          .setCustomId('decline_mediator')
          .setLabel('رفض')
        .setDisabled(true)
          .setStyle(ButtonStyle.Danger)
      );
      await interaction.message.edit({
components: [row]
      })
    } else if (interaction.customId === "accept_mediator")  {
      if (!interaction.member.roles.cache.has("1224829322926227640")) return interaction.reply({ content: `You don't have permission to use this button.`, ephemeral: true })
      const member = interaction.message.content.slice(2, 20);
      const user = interaction.guild.members.cache.get(member);
      const channel = interaction.guild.channels.cache.get("1226483877770563606");
      user.roles.add("1226500959849680896").catch((e) => console.log(e));
      const embed = new EmbedBuilder()
        .setTitle("تم قبولك")
        .setDescription(`تم قبولك كـ وسيط بسيرفر ريدبول 
 حياك للتعليم و الأختبار ( #❃〢تكت・تعليم・أختبار )
`)
      .setColor("#000100")

.setAuthor({
            name: interaction.guild.name,
            iconURL: interaction.guild.iconURL()
          })
          .setFooter({
            text: interaction.guild.name,
            iconURL: interaction.guild.iconURL()
          })
          .setThumbnail(interaction.guild.iconURL())
        .setTimestamp();
      await channel.send({
       content: `> <@${member}>`,
       embeds: [embed]
      });
      
      
      
      await interaction.reply({
        content: `تم قبول <@${member}> كـ وسيط بسيرفر ريدبول`,
        ephemeral: true,
      })
                  const row = new ActionRowBuilder()
      .addComponents(
        new ButtonBuilder()
          .setCustomId('accept_mediator')
          .setLabel(`تم قبول المقدم من قبل ${interaction.user.tag}`)
        .setDisabled(true)
.setStyle(ButtonStyle.Success),
        new ButtonBuilder()
          .setCustomId('decline_mediator')
          .setLabel('رفض')
        .setDisabled(true)
          .setStyle(ButtonStyle.Danger)
      );
      await interaction.message.edit({
components: [row]
      })
    } else if (interaction.customId === "accept_report") {
      if (!interaction.member.roles.cache.has("1224829322926227640")) return interaction.reply({ content: `You don't have permission to use this button.`, ephemeral: true })
      const member = interaction.message.content.slice(2, 20);
      const user = interaction.guild.members.cache.get(member);
      const channel = interaction.guild.channels.cache.get("1226483877770563606");
      user.roles.add("1226500959849680896").catch((e) => console.log(e));
      const embed = new EmbedBuilder()
        .setTitle("تم قبولك")
        .setDescription(`تم قبولك كـ قاضي بسيرفر ريدبول 
 حياك للتعليم و الأختبار ( #❃〢تكت・التعليم )`)
      .setColor("#000100")

.setAuthor({
            name: interaction.guild.name,
            iconURL: interaction.guild.iconURL()
          })
          .setFooter({
            text: interaction.guild.name,
            iconURL: interaction.guild.iconURL()
          })
          .setThumbnail(interaction.guild.iconURL())
        .setTimestamp();
      await channel.send({
       content: `> <@${member}>`,
       embeds: [embed]
      });
      
      
      
      await interaction.reply({
        content: `تم قبول <@${member}> كـ قاضي بسيرفر ريدبول`,
        ephemeral: true,
      })
                  const row = new ActionRowBuilder()
      .addComponents(
        new ButtonBuilder()
          .setCustomId('accept_mediator')
          .setLabel(`تم قبول المقدم من قبل ${interaction.user.tag}`)
        .setDisabled(true)
.setStyle(ButtonStyle.Success),
        new ButtonBuilder()
          .setCustomId('decline_mediator')
          .setLabel('رفض')
        .setDisabled(true)
          .setStyle(ButtonStyle.Danger)
      );
      await interaction.message.edit({
components: [row]
      })
    }
  }
});