const client = require("../../index.js");
const { EmbedBuilder, ApplicationCommandOptionType , Events , ActionRowBuilder , ButtonBuilder ,MessageAttachment, ButtonStyle , Message, TextInputStyle,TextInputBuilder,ModalBuilder, StringSelectMenuBuilder, StringSelectMenuOptionBuilder, PermissionsBitField } = require("discord.js");
client.on('interactionCreate', async interaction => {
  if (!interaction.isButton()) return;
  if (interaction.customId === 'Submit_report') {
    const modal = new ModalBuilder()
      .setCustomId('report_modal')
      .setTitle('تقديم بلاغ');
    const scam_id = new TextInputBuilder()
      .setCustomId('scam_id')
      .setLabel("ايدي النصاب")
.setStyle(TextInputStyle.Short)
      .setRequired(true)
      .setPlaceholder('حط هنا ايدي النصاب و ليس يوزره');
    const reporter_id = new TextInputBuilder()
   .setCustomId('reporter_id')
      .setLabel("ايدي المنصوب")
.setStyle(TextInputStyle.Short)
      .setRequired(true)
      .setPlaceholder('حط ايدي بتاع الشخص المنصوب');
    const the_story = new TextInputBuilder()
      .setCustomId('the_story')
      .setLabel("القصه")
.setStyle(TextInputStyle.Paragraph)
      .setRequired(true)
      .setPlaceholder('حط القصه هنا بشكل مختصر');
    const price = new TextInputBuilder()
      .setCustomId('price')
      .setLabel("المبلغ")
.setStyle(TextInputStyle.Short)
      .setRequired(true)
      .setPlaceholder('حط المبلغ  الي نصب عليك فيه');
    const item = new TextInputBuilder()
      .setCustomId('item')
      .setLabel("السلعه")
.setStyle(TextInputStyle.Short)
      .setRequired(true)
      .setPlaceholder('حط السلعه الي نصب عليه فيه');
    const row1 = new ActionRowBuilder().addComponents(scam_id);
    const row2 = new ActionRowBuilder().addComponents(reporter_id);
    const row3 = new ActionRowBuilder().addComponents(the_story);
    const row4 = new ActionRowBuilder().addComponents(price);
    const row5 = new ActionRowBuilder().addComponents(item);
    modal.addComponents(row1, row2, row3, row4, row5);
    await interaction.showModal(modal);
  }
});
client.on('interactionCreate', async interaction => {
  if (!interaction.isModalSubmit()) return;
  if (interaction.customId === 'report_modal') {
    const scam_id = interaction.fields.getTextInputValue('scam_id');
    const reporter_id = interaction.fields.getTextInputValue('reporter_id');
    const the_story = interaction.fields.getTextInputValue('the_story');
    const price = interaction.fields.getTextInputValue('price');
    const item = interaction.fields.getTextInputValue('item');
    const embed = new EmbedBuilder()
      .setColor('#000100')
      .setTitle(`**بلاغ  علي نصاب**`)
      .addFields(
        {
          name: "النصاب",
          value: `<@${scam_id}>\n(${scam_id})`
        },
        {
          name: "المنصوب",
          value: `<@${reporter_id}>\n(${reporter_id})`
        },
        {
          name: "السلعه",
          value: `${item}`
        },
        {
          name: "المبلغ",
          value: `${price}`
        },
        {
          name: "القصه",
          value: `${the_story}`
        }
      )
      .setAuthor({
        name: interaction.guild.name,
        iconURL: interaction.guild.iconURL()})
        .setFooter({
        text: interaction.guild.name,
          iconURL: interaction.guild.iconURL()
        })

        .setThumbnail(interaction.guild.iconURL())
      .setTimestamp();
    
    interaction.reply({
      embeds: [embed]
    })
    await interaction.channel.send({
      content: `**الخطوة التالية : دلوقتي لازم ترسل الدلائل محتاجينك منك الاتي 

- دليل الاتفاق علي : (${item}) بينك وبين النصاب
- ودليل انه نصب عليك : (يعني عملك بلوك , السلعه مش شغاله , مش بيرد عليك) 
- واخر دليل : دليل تحويل الكريديت للنصاب**`
    })
  const row = new ActionRowBuilder()
        .addComponents(
          new ButtonBuilder()
            .setCustomId('Submit_report')
            .setLabel('تم تقديم بلاغ بنجاح')
.setStyle(ButtonStyle.Secondary)
            .setDisabled(true),
          new ButtonBuilder()
            .setCustomId('get_report')
            .setLabel('رفع بلاغ')
          .setStyle(ButtonStyle.Secondary),
          new ButtonBuilder()
          .setCustomId('report_claim')
            .setLabel('استلام التذكره')
          .setStyle(ButtonStyle.Secondary),
          new ButtonBuilder()
            .setCustomId('report_help')
            .setLabel('مساعده القضاه')
          .setStyle(ButtonStyle.Secondary),
          new ButtonBuilder()
          .setCustomId('report_delete_ticket')
            .setLabel('حذف التذكره')
          .setStyle(ButtonStyle.Secondary)
        );
      await interaction.message.edit({ components: [row] });
    
  }
});